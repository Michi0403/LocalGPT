# Minecraft Loader Matrix

Prompt:
Generate a downloadable Minecraft Java project skeleton distinction zip that contains separate Fabric, Paper, and NeoForge skeletons for Minecraft 1.21.4, with each loader using its own metadata and Gradle dependency conventions.

This artifact intentionally contains three different Java Edition skeleton families:

- `fabric/`: Fabric mod skeleton with Fabric metadata/dependencies.
- `paper/`: Paper plugin skeleton with plugin.yml and server plugin conventions.
- `neoforge/`: NeoForge mod skeleton with NeoForge metadata/dependencies.

Validation rule: do not reuse one loader's metadata files for another loader.
Minecraft version: 1.21.4
Generated UTC: 2026-06-08T11:12:03.1767141Z