package com.localgpt.matrix.fabric;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FabricLoaderMatrixMod implements ModInitializer {
    public static final String MOD_ID = "fabric_loader_matrix";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("LocalGPT generated mod loaded: {}", MOD_ID);
    }
}