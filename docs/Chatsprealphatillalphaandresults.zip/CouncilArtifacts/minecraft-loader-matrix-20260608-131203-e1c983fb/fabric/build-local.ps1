[CmdletBinding()]
param(
    [string]$Task = "build"
)

$ErrorActionPreference = "Stop"

$javaHome = $env:JAVA_HOME
if ([string]::IsNullOrWhiteSpace($javaHome) -or -not (Test-Path (Join-Path $javaHome "bin\java.exe"))) {
    $javaCandidate = Join-Path $env:ProgramFiles "Microsoft\jdk-21.0.11.10-hotspot"
    if (Test-Path (Join-Path $javaCandidate "bin\java.exe")) {
        $javaHome = $javaCandidate
    }
}

if ([string]::IsNullOrWhiteSpace($javaHome) -or -not (Test-Path (Join-Path $javaHome "bin\java.exe"))) {
    throw "JDK 21 was not found. Install Microsoft.OpenJDK.21 or run LocalGPTWebviewWrapper\build\Setup-MinecraftModToolchain.ps1 -Install."
}

$env:JAVA_HOME = $javaHome
$env:Path = "$(Join-Path $javaHome "bin");$env:Path"

$localGradle = Join-Path $env:LOCALAPPDATA "LocalGPT\Tools\gradle-8.14.2\bin\gradle.bat"
if (Test-Path $localGradle) {
    & $localGradle $Task
    exit $LASTEXITCODE
}

$globalGradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($null -ne $globalGradle) {
    & $globalGradle.Source $Task
    exit $LASTEXITCODE
}

throw "Gradle 8.14.2 was not found. Run LocalGPTWebviewWrapper\build\Setup-MinecraftModToolchain.ps1 -InstallGradle."