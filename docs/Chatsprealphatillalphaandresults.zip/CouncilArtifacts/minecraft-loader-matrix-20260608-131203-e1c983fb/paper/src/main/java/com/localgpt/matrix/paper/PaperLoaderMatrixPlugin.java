package com.localgpt.matrix.paper;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public class PaperLoaderMatrixPlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("LocalGPT generated Living Cities Paper plugin loaded.");
    }

    @Override
    public boolean onCommand(
        @NotNull CommandSender sender,
        @NotNull Command command,
        @NotNull String label,
        @NotNull String[] args
    ) {
        if (!command.getName().equalsIgnoreCase("livingcities")) {
            return false;
        }

        sender.sendMessage(LivingCitiesReport.createDemoReport());
        return true;
    }
}