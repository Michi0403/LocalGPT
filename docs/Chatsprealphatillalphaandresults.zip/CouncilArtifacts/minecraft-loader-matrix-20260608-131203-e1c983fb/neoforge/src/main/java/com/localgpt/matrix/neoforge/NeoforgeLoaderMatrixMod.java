package com.localgpt.matrix.neoforge;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(NeoforgeLoaderMatrixMod.MOD_ID)
public class NeoforgeLoaderMatrixMod {
    public static final String MOD_ID = "neoforge_loader_matrix";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public NeoforgeLoaderMatrixMod(IEventBus modEventBus) {
        LOGGER.info("LocalGPT generated mod loaded: {}", MOD_ID);
    }
}