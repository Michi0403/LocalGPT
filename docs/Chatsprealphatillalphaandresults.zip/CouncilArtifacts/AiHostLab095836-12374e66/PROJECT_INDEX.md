# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab095836/Program.cs",
    "src/AiHostLab095836/Components/Pages/Index.razor",
    "src/AiHostLab095836/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab095836/Components/Pages/SourceFidelity.razor",
"src/AiHostLab095836/Components/Pages/Chat.razor",
"src/AiHostLab095836/Components/Pages/RunningModels.razor",
"src/AiHostLab095836/Components/Pages/ModelDownloads.razor",
"src/AiHostLab095836/Components/Pages/Templates.razor",
"src/AiHostLab095836/Components/Pages/Hardware.razor",
"src/AiHostLab095836/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab095836/Components/Pages/Logs.razor",
"src/AiHostLab095836/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab095836/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab095836/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab095836/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab095836/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab095836/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab095836/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab095836/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab095836/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab095836/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab095836/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab095836/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab095836/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab095836/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab095836/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab095836/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab095836/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab095836/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab095836.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab095836/AiHostLab095836.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab095836/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab095836/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab095836/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab095836/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab095836/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab095836/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab095836/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab095836/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab095836/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab095836/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab095836/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab095836/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab095836/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab095836/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab095836/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Answer this DXAiChat conversation as the LocalGPT AI Council. Use the selected members, preserve user intent, and include a concise consensus. User: Hi, welcome a new member to the team, gemma4! Be welcome Gemma. I have a technical windows issue and the problem is, that I often get blackscreens and it shows only in the Eventlog as Hardware Issue. Sometimes it seems Cpu related, Sometimes Memory, Sometimes GPU but it ends always with several reboots necessary because the AMD Video Driver can't get somehow recoverd by windows. Sometimes till a state where I need to get in the save mode of Windows 11 to reinstall the AMD Driver after using their Cleanup Kit. I don't understand why or what happens and especially why the drivers dies in such a horrible way that it sometimes it's even impossible by the operation system Windows 11 to recover it? Assistant: _AI Council started with 5 member(s):...

## Council Summary

**LocalGPT AI Council – Consensus Response** --- ### 1. Final Answer (User‑Visible) Gemma4 has crashed during its proposal phase with a stack‑overflow error (`GGML_ASSERT`). This is a runtime issue in the Ollama environment, not a malicious block. We have **excluded Gemma4 from this council round** to keep the discussion focused and reliable. If you want to re‑include it later, restart the Ollama server, clear its cache (`ollama serve --reset`), ensure the model is fully downloaded, and then retry the council prompt. Below is a concise troubleshooting plan for your AMD driver crashes that we can apply immediately: | # | Action | Why it Helps | |---|--------|--------------| | 1 | **Boot into Safe Mode** → run **AMD Cleanup Utility (DDU)** in silent mode (`ddu.exe /s /q`). | Removes corrupted registry entries and leftover kernel modules. | | 2 | **Reboot normally** → install the *latest st...