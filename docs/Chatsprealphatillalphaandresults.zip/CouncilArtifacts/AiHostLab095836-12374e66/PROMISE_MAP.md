# Promise Map

Generated project: `AiHostLab095836`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/ai-prompt-flow` | `AIPromptFlow.razor` | Promise-derived surface for prompt-to-plan workflows, model/provider calls, generated briefs, and Needs verification notes. | Prompt, Provider call, Generated brief, Verification |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Answer this DXAiChat conversation as the LocalGPT AI Council. Use the selected members, preserve user intent, and include a concise consensus. User: Hi, welcome a new member to the team, gemma4! Be welcome Gemma. I have a technical windows issue and the problem is, that I often get blackscreens and it shows only in the Eventlog as Hardware Issue. Sometimes it seems Cpu related, Sometimes Memory, Sometimes GPU but it ends always with several reboots necessary because the AMD Video Driver can't get somehow recoverd by windows. Sometimes till a state where I need to get in the save mode of Windows 11 to reinstall the AMD Driver after using their Cleanup Kit. I don't understand why or what happens and especially why the drivers dies in such a horrible way that it sometimes it's even impossible by the operation system Windows 11 to recover it? Assistant: _AI Council started with 5 member(s): gpt-oss:20b, deepseek-r1:8b, gemma3:27b, gemma4:latest, qwen3-coder:30b. Local models may take a while; progress/status stays visible, detailed model output is inspectable, and the final result appears in a clean Council result block._ _Council status: Council selected 4 member(s): gpt-oss:20b, deep...
```

## Council Excerpt

```text
**LocalGPT AI Council – Consensus Response** --- ### 1. Final Answer (User‑Visible) Gemma4 has crashed during its proposal phase with a stack‑overflow error (`GGML_ASSERT`). This is a runtime issue in the Ollama environment, not a malicious block. We have **excluded Gemma4 from this council round** to keep the discussion focused and reliable. If you want to re‑include it later, restart the Ollama server, clear its cache (`ollama serve --reset`), ensure the model is fully downloaded, and then retry the council prompt. Below is a concise troubleshooting plan for your AMD driver crashes that we can apply immediately: | # | Action | Why it Helps | |---|--------|--------------| | 1 | **Boot into Safe Mode** → run **AMD Cleanup Utility (DDU)** in silent mode (`ddu.exe /s /q`). | Removes corrupted registry entries and leftover kernel modules. | | 2 | **Reboot normally** → install the *latest stable* AMD Radeon Software or a known‑stable previous version. | Fresh driver eliminates buggy kernel code; older versions are often more compatible with Windows 11. | | 3 | **Disable GPU over‑clocking / custom power profiles** in BIOS/UEFI and Radeon settings. | Reduces memory corruption that can crash the driver. | | 4 | **Update your BIOS/UEFI** to the latest firmware from your motherboard manufacturer. | Fixes firmware bugs that surface as GPU driver failures. | | 5 | **Run MemTest86** (bootable USB) for at least 4 full passes, and run Windows Memory Diagnostic. | Detects faulty RAM that can corrupt GPU memory. | | 6 | **Check Event Viewer → System logs** for error codes such as `0x000001...
```