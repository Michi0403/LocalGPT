# Promise Map

Generated project: `LocalGPTApp131210`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/download-center` | `DownloadCenter.razor` | Promise-derived surface for generated files, MIME types, safe HTTP GET links, checksums, expiry, and user-visible artifact status. | Generated files, HTTP GET, Checksum, Expiry |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Generate a downloadable whole solution zip that can stand in for LocalGPT as a local-first AI workbench. It must include DXAiChat, AI Council with minimum two-member feedback talk, SQLite memory and knowledge approval markers, artifact download routes, Minecraft builder, install/setup, and Test Lab surfaces. No missing feature is acceptable; if a capability is not implemented, represent it as a visible backend service boundary and capability gap.
```

## Council Excerpt

```text
Benchmark answer: create a full LocalGPT-like workbench solution zip with distinct pages for DXAiChat, AI Council, SQLite, Minecraft, Install, and Test Lab. Include Implementation artifact request.
```