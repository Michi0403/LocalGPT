# Source Fidelity

Generated project: `LocalGPTApp131210`

## Acceptance Rule

A generated solution is not accepted merely because it compiles. It must preserve the requested source application's recognizable workflows, navigation, service boundaries, persistence shape, diagnostics, and download/artifact behavior.

## Expected Shape

A LocalGPT replacement must look and behave like a local-first AI workbench: DXAiChat, AI Council, SQLite memory/knowledge, artifact downloads, Minecraft builder, Install, Test Lab, diagnostics, and visible model/runtime status.

## Dynamic Promise Modules

- `/download-center` / `DownloadCenter.razor`: Promise-derived surface for generated files, MIME types, safe HTTP GET links, checksums, expiry, and user-visible artifact status.
- `/persistence` / `Persistence.razor`: Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge.

## Review Files

- `src/LocalGPTApp131210/Components/Pages/SourceFidelity.razor`
- `src/LocalGPTApp131210/Services/GeneratedSourceFidelityService.cs`
- `PROJECT_INDEX.md`
- `.localgpt-generation.json`
- `ARCHITECTURE.md`

## Benchmark Guidance

LocalGPT replacement benchmarks should inspect this file and the generated source-fidelity service before awarding architecture points. A page-only solution should score low when it misses source workflows, service contracts, or persistence boundaries.

## Integration Rule

This remains a sandbox artifact. Copying generated files into a real repo requires explicit user approval, a build, and a focused smoke test.