# Project Index

## Purpose

Prototype a LocalGPT/TacosPortalOpen-style AI Council feature workspace with reviewable Blazor pages.

## Archetype

```json
{
  "project_kind": "localgpt_feature",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": false,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/LocalGPTApp131210/Program.cs",
    "src/LocalGPTApp131210/Components/Pages/Index.razor",
    "src/LocalGPTApp131210/Components/Pages/GeneratedDashboard.razor",
    "src/LocalGPTApp131210/Components/Pages/SourceFidelity.razor"
  ]
}
```

## Entry Points

- `src/LocalGPTApp131210/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/LocalGPTApp131210/Components/App.razor` - document shell and static asset links.
- `src/LocalGPTApp131210/Components/Routes.razor` - Blazor route discovery.
- `src/LocalGPTApp131210/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/LocalGPTApp131210/Components/Pages/Index.razor` - first viewport and page hub.
- `src/LocalGPTApp131210/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/LocalGPTApp131210/Components/Pages/GeneratedKnowledgeTable.razor route `/knowledge`` - archetype catalog page.
- `src/LocalGPTApp131210/Components/Pages/ImplementationPlan.razor route `/implementation-plan`` - archetype-specific detail page.
- `src/LocalGPTApp131210/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.


## Generated Files

| File | Why it exists |
| --- | --- |
| `LocalGPTApp131210.sln` | Visual Studio and CLI solution entry point. |
| `src/LocalGPTApp131210/LocalGPTApp131210.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/LocalGPTApp131210/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/LocalGPTApp131210/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/LocalGPTApp131210/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |

| `src/LocalGPTApp131210/wwwroot/app.css` | Local styling for the generated shell. |
| `src/LocalGPTApp131210/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/LocalGPTApp131210/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Generate a downloadable whole solution zip that can stand in for LocalGPT as a local-first AI workbench. It must include DXAiChat, AI Council with minimum two-member feedback talk, SQLite memory and knowledge approval markers, artifact download routes, Minecraft builder, install/setup, and Test Lab surfaces. No missing feature is acceptable; if a capability is not implemented, represent it as a visible backend service boundary and capability gap.

## Council Summary

Benchmark answer: create a full LocalGPT-like workbench solution zip with distinct pages for DXAiChat, AI Council, SQLite, Minecraft, Install, and Test Lab. Include Implementation artifact request.