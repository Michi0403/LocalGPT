# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab063458/Program.cs",
    "src/AiHostLab063458/Components/Pages/Index.razor",
    "src/AiHostLab063458/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab063458/Components/Pages/SourceFidelity.razor",
"src/AiHostLab063458/Components/Pages/Chat.razor",
"src/AiHostLab063458/Components/Pages/RunningModels.razor",
"src/AiHostLab063458/Components/Pages/ModelDownloads.razor",
"src/AiHostLab063458/Components/Pages/Templates.razor",
"src/AiHostLab063458/Components/Pages/Hardware.razor",
"src/AiHostLab063458/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab063458/Components/Pages/Logs.razor",
"src/AiHostLab063458/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab063458/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab063458/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab063458/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab063458/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab063458/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab063458/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab063458/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab063458/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab063458/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab063458/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab063458/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab063458/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab063458/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab063458/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab063458/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab063458/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab063458/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab063458.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab063458/AiHostLab063458.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab063458/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab063458/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab063458/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab063458/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab063458/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab063458/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab063458/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab063458/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab063458/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab063458/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab063458/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab063458/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab063458/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab063458/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab063458/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

nd execute them even for new structures. But we also need to tune the SQLite Editor, the whole frontend is still weak. But since I implemented logging and try catch everywhere it works fluently without deeper crashes yet! Review that as well and corresponding code changes, repeat till done. Assistant: _AI Council started with 4 member(s): gpt-oss:20b, qwen3-coder:30b, deepseek-r1:8b, gemma3:27b. Local models may take a while; progress/status stays visible, detailed model output is inspectable, and the final result appears in a clean Council result block._ _Council status: Council selected 4 member(s): gpt-oss:20b, qwen3-coder:30b, deepseek-r1:8b, gemma3:27b. Max output tokens: 262144; context cap: 262.144; parallel models: 1._ _Council status: Starting council phase: round 1, Proposal, role Independent proposal._ _Council status: Starting gpt-oss:20b: Proposal / Independent proposal. Oll...

## Council Summary

**gemma3:27b failed during Consensus.** An error occurred while sending the request.