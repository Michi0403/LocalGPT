# Promise Map

Generated project: `AiHostLab063458`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |
| `/devexpress-ui` | `DevExpressUI.razor` | Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification. | Navigation, Grid, Form, Frontend smoke |
| `/api-contracts` | `APIContracts.razor` | Promise-derived surface for backend routes, request/response DTOs, validation, errors, and smoke-test calls. | Routes, DTOs, Validation, Smoke tests |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
nd execute them even for new structures. But we also need to tune the SQLite Editor, the whole frontend is still weak. But since I implemented logging and try catch everywhere it works fluently without deeper crashes yet! Review that as well and corresponding code changes, repeat till done. Assistant: _AI Council started with 4 member(s): gpt-oss:20b, qwen3-coder:30b, deepseek-r1:8b, gemma3:27b. Local models may take a while; progress/status stays visible, detailed model output is inspectable, and the final result appears in a clean Council result block._ _Council status: Council selected 4 member(s): gpt-oss:20b, qwen3-coder:30b, deepseek-r1:8b, gemma3:27b. Max output tokens: 262144; context cap: 262.144; parallel models: 1._ _Council status: Starting council phase: round 1, Proposal, role Independent proposal._ _Council status: Starting gpt-oss:20b: Proposal / Independent proposal. Ollama num_gpu=auto._ <details class="council-step council-live" open><summary>gpt-oss:20b — Proposal / Independent proposal live output</summary> <p class="localgpt-stream-status"><em>LocalGPT sent the request to Ollama model gpt-oss:20b. Waiting for the local runtime to accept the stream...</em></p>...
```

## Council Excerpt

```text
**gemma3:27b failed during Consensus.** An error occurred while sending the request.
```