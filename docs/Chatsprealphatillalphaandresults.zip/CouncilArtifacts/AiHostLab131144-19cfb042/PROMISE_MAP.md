# Promise Map

Generated project: `AiHostLab131144`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/devexpress-ui` | `DevExpressUI.razor` | Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification. | Navigation, Grid, Form, Frontend smoke |
| `/api-contracts` | `APIContracts.razor` | Promise-derived surface for backend routes, request/response DTOs, validation, errors, and smoke-test calls. | Routes, DTOs, Validation, Smoke tests |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
implementation-request smoke: generate a whole local AI host .NET 10 ASP.NET Core and DevExpress Blazor solution zip. Use only .NET, C#, Razor, and DevExpress Blazor. Include a left navigation shell, model catalog, chat, downloads, running models, API console, settings, logs, and selected provider-compatible API routes such as /api/version, /api/tags, /api/ps, /api/chat, and /api/generate. The generated host should delegate to an approved external Ollama-compatible provider URL by default, then fall back safely when that provider is unavailable. Do not use Go and do not claim native GGML/GPU inference is implemented.
```

## Council Excerpt

```text
Create a downloadable .NET 10 ASP.NET Core and DevExpress Blazor AI host control-plane lab. Include a left navigation app shell, typed model catalog records, chat/download/running-model/API-console/settings/log pages, selected REST routes, README, manifest, external-provider delegation to an Ollama-compatible URL, and a prominent note that native inference is not implemented without a real backend.
```