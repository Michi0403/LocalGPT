# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab131144/Program.cs",
    "src/AiHostLab131144/Components/Pages/Index.razor",
    "src/AiHostLab131144/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab131144/Components/Pages/SourceFidelity.razor",
"src/AiHostLab131144/Components/Pages/Chat.razor",
"src/AiHostLab131144/Components/Pages/RunningModels.razor",
"src/AiHostLab131144/Components/Pages/ModelDownloads.razor",
"src/AiHostLab131144/Components/Pages/Templates.razor",
"src/AiHostLab131144/Components/Pages/Hardware.razor",
"src/AiHostLab131144/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab131144/Components/Pages/Logs.razor",
"src/AiHostLab131144/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab131144/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab131144/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab131144/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab131144/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab131144/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab131144/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab131144/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab131144/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab131144/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab131144/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab131144/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab131144/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab131144/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab131144/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab131144/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab131144/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab131144/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab131144.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab131144/AiHostLab131144.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab131144/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab131144/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab131144/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab131144/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab131144/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab131144/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab131144/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab131144/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab131144/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab131144/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab131144/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab131144/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab131144/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab131144/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab131144/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

implementation-request smoke: generate a whole local AI host .NET 10 ASP.NET Core and DevExpress Blazor solution zip. Use only .NET, C#, Razor, and DevExpress Blazor. Include a left navigation shell, model catalog, chat, downloads, running models, API console, settings, logs, and selected provider-compatible API routes such as /api/version, /api/tags, /api/ps, /api/chat, and /api/generate. The generated host should delegate to an approved external Ollama-compatible provider URL by default, then fall back safely when that provider is unavailable. Do not use Go and do not claim native GGML/GPU inference is implemented.

## Council Summary

Create a downloadable .NET 10 ASP.NET Core and DevExpress Blazor AI host control-plane lab. Include a left navigation app shell, typed model catalog records, chat/download/running-model/API-console/settings/log pages, selected REST routes, README, manifest, external-provider delegation to an Ollama-compatible URL, and a prominent note that native inference is not implemented without a real backend.