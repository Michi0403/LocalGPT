# Design Review

Generated project: `AiHostLab131144`

## Layout Choice

The artifact uses a compact operational layout: top navigation, dashboard/status grid, source-fidelity review, and one page per detected promise module. It avoids a marketing-style landing page because generated LocalGPT artifacts are tools first.

## Base Archetype

`AiHost`

## Dynamic UI Modules

- `Document Exports` uses DevExpress grid/form patterns to expose Report template, Format mapping, Backend service, Download route.
- `Model Host Status` uses DevExpress grid/form patterns to expose Provider, Model catalog, Reachability, Runtime status.
- `DevExpress UI` uses DevExpress grid/form patterns to expose Navigation, Grid, Form, Frontend smoke.
- `API Contracts` uses DevExpress grid/form patterns to expose Routes, DTOs, Validation, Smoke tests.

## Components Used

- DevExpress Blazor navigation-friendly pages.
- `DxGrid` for scan-friendly operational state.
- `DxFormLayout`, `DxTextBox`, and `DxMemo` for bounded review and settings surfaces.
- Bootstrap-compatible CSS for responsive grid and toolbar layout.
- Paired SVG navigation icons with line/solid states.

## Mocked Versus Real

Mocked: generated rows, status values, and sample implementation boundaries.

Real: routable Razor files, compileable project structure, static CSS/icons, docs, generation manifest, and source-fidelity contract.

## Needs Wiring

- Replace generated sample services with real backend services.
- Add EF/SQLite persistence if user-visible state must survive restarts.
- Add route smoke tests for every generated endpoint.
- Add real DevExpress report/export implementation only after package/API verification and user approval.