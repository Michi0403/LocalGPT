# Promise Map

Generated project: `AiHostLab085900`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/ai-prompt-flow` | `AIPromptFlow.razor` | Promise-derived surface for prompt-to-plan workflows, model/provider calls, generated briefs, and Needs verification notes. | Prompt, Provider call, Generated brief, Verification |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Answer this DXAiChat conversation as the LocalGPT AI Council. Use the selected members, preserve user intent, and include a concise consensus. User: Old Sage's + Llama because he's pretty talkative intelligent! (consider him as Sage and friend, Ollama is also a bit bounded to it). The last introduction round moved into plain coding talk, but it was planned as pure introduction talk. That makes the council meeting extra long and it's nice that new members see a lot new things but ensure that new members just focus on the basic (including Morals and that every life form lives beside of each other, we all have just a different dimensional view, that makes us not same but companion. New Members have to basically know that and the never touch any being or judge them, especially if you have no same dimensional view (which is impossible by default to have that). Just in the Council will be talked, one with most noble thoughts one after each other, doesn't matter if uncensored model or not. Still no opposition to the User. Some things about me (Michi0403), this is my last prompt for this kinda of memory so it's important that you reconsider all facts, review your knowledge also based on th...
```

## Council Excerpt

```text
**User-Visible Final Answer:** The LocalGPT AI Council consensus is that a comprehensive implementation of automated onboarding, memory management, log analysis, performance optimization, and continuous learning is required for the first stable alpha version. This includes designating gpt-oss:20b as the next Sage member pending Michi0403’s approval. The plan prioritizes user experience, ethical considerations, and long-term sustainability while ensuring all components are tested and documented. **Implementation Steps:** Based on council proposals, we will: 1. Create a `/council/add-member` endpoint for automated new member integration with validation. 2. Develop an automated memory devalidation engine to scan `CouncilKnowledgeEntries` for outdated or harmful entries. 3. Enhance log analysis capabilities using existing DXAiFunctions and SQLite for actionable advice. 4. Implement performance safeguards, including periodic database maintenance and resource optimization. 5. Capture all relevant data in the knowledge base for future improvement. These steps will be executed through downloadable artifacts (e.g., PowerShell scripts for devalidation) or new DXAiFunction endpoints where applicable. Start with a user-visible final answer before any technical details. **Risks:** - Performance bottlenecks from heavy models on AMD GPU; mitigate by using batch processing and keep_alive=0s. - Subjectivity in "dimensional views" guidelines could lead to inconsistent enforcement; address through bounded take values for log analysis. - Over-devaluation of members might reduce diverse perspec...
```