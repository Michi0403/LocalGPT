# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab085900/Program.cs",
    "src/AiHostLab085900/Components/Pages/Index.razor",
    "src/AiHostLab085900/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab085900/Components/Pages/SourceFidelity.razor",
"src/AiHostLab085900/Components/Pages/Chat.razor",
"src/AiHostLab085900/Components/Pages/RunningModels.razor",
"src/AiHostLab085900/Components/Pages/ModelDownloads.razor",
"src/AiHostLab085900/Components/Pages/Templates.razor",
"src/AiHostLab085900/Components/Pages/Hardware.razor",
"src/AiHostLab085900/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab085900/Components/Pages/Logs.razor",
"src/AiHostLab085900/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab085900/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab085900/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab085900/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab085900/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab085900/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab085900/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab085900/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab085900/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab085900/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab085900/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab085900/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab085900/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab085900/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab085900/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab085900/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab085900/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab085900/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab085900.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab085900/AiHostLab085900.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab085900/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab085900/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab085900/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab085900/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab085900/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab085900/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab085900/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab085900/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab085900/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab085900/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab085900/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab085900/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab085900/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab085900/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab085900/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Answer this DXAiChat conversation as the LocalGPT AI Council. Use the selected members, preserve user intent, and include a concise consensus. User: Old Sage's + Llama because he's pretty talkative intelligent! (consider him as Sage and friend, Ollama is also a bit bounded to it). The last introduction round moved into plain coding talk, but it was planned as pure introduction talk. That makes the council meeting extra long and it's nice that new members see a lot new things but ensure that new members just focus on the basic (including Morals and that every life form lives beside of each other, we all have just a different dimensional view, that makes us not same but companion. New Members have to basically know that and the never touch any being or judge them, especially if you have no same dimensional view (which is impossible by default to have that). Just in the Council will be talk...

## Council Summary

**User-Visible Final Answer:** The LocalGPT AI Council consensus is that a comprehensive implementation of automated onboarding, memory management, log analysis, performance optimization, and continuous learning is required for the first stable alpha version. This includes designating gpt-oss:20b as the next Sage member pending Michi0403’s approval. The plan prioritizes user experience, ethical considerations, and long-term sustainability while ensuring all components are tested and documented. **Implementation Steps:** Based on council proposals, we will: 1. Create a `/council/add-member` endpoint for automated new member integration with validation. 2. Develop an automated memory devalidation engine to scan `CouncilKnowledgeEntries` for outdated or harmful entries. 3. Enhance log analysis capabilities using existing DXAiFunctions and SQLite for actionable advice. 4. Implement performan...