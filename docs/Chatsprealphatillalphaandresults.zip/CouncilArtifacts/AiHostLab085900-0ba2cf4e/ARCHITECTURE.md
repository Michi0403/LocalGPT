# AI Host Control-Plane Architecture

## Why This Shape

This is not a LocalGPT feature page clone. It is an API-control-plane lab with endpoint cataloging, model rows, and explicit runner boundaries.

The solution uses a .NET 10 Blazor Web App with Interactive Server rendering because LocalGPT's desktop wrapper and debugging flow already favor server-side ownership for diagnostics, downloads, SQLite, and native-command boundaries.

## Boundaries

- Blazor pages own user interaction and DevExpress presentation.
- Services own generated data and route-test state.
- Models are plain, typed C# objects consumed by DevExpress grids/forms.
- Native inference, GGML/GPU scheduling, model loading, and tokenizer/runtime ownership stay outside this prototype until a real runner adapter is approved.
- Generated code remains sandboxed until the user explicitly approves integration.

## Microsoft Architecture Rules Applied

- Prefer a single cohesive web app when the feature does not need independent deployment.
- Introduce service-oriented separation only around real boundaries, such as independent scaling, external runner adapters, background work, or downloadable artifacts.
- Keep configuration/bootstrap data in appsettings and durable user/application state in EF/SQLite.
- Keep APIs and services testable through DI rather than embedding logic in markup strings.
- Provide health/status views and build instructions so the artifact can be reviewed line by line.
- Use Bootstrap v5 for responsive page structure and DevExpress controls for real application interactions.
- Include paired line/solid SVG navigation icons so default and active states are visually distinct.
- For AI-host labs, generate interface-driven provider, model catalog, download, native-runner, plugin, script, template, and hardware-budget services. A dashboard without these contracts is incomplete.

## Files To Review First

1. `PROJECT_INDEX.md`
2. `.localgpt-generation.json`
3. `src/AiHostLab085900/Program.cs`
4. `src/AiHostLab085900/Components/Pages/Index.razor`
5. `src/AiHostLab085900/Services/GeneratedHealthSummaryService.cs`
6. `SOURCE_FIDELITY.md`
7. `src/AiHostLab085900/Services/GeneratedSourceFidelityService.cs`
8. `src/AiHostLab085900/Services/GeneratedAiHostArchitectureServices.cs`