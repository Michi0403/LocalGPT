# Promise Map

Generated project: `AiHostLab131223`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |
| `/devexpress-ui` | `DevExpressUI.razor` | Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification. | Navigation, Grid, Form, Frontend smoke |
| `/api-contracts` | `APIContracts.razor` | Promise-derived surface for backend routes, request/response DTOs, validation, errors, and smoke-test calls. | Routes, DTOs, Validation, Smoke tests |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Generate a downloadable whole solution zip for a provider-neutral AI host replacement in .NET 10, ASP.NET Core, Blazor, and DevExpress. It must include model catalog, chat, downloads, running models, API console, logs, settings, templates, hardware, runner/plugins, /api/version, /api/tags, /api/ps, /api/chat, /api/generate, OpenAI-compatible routes, direct local model-file runner interfaces, Python.NET/PowerShell extension boundaries, and SQLite/appsettings state.
```

## Council Excerpt

```text
Benchmark answer: create a buildable AI-host replacement solution zip with DevExpress pages, provider-compatible routes, runner/plugin service contracts, and no Go dependency. Include Implementation artifact request.
```