# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab131223/Program.cs",
    "src/AiHostLab131223/Components/Pages/Index.razor",
    "src/AiHostLab131223/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab131223/Components/Pages/SourceFidelity.razor",
"src/AiHostLab131223/Components/Pages/Chat.razor",
"src/AiHostLab131223/Components/Pages/RunningModels.razor",
"src/AiHostLab131223/Components/Pages/ModelDownloads.razor",
"src/AiHostLab131223/Components/Pages/Templates.razor",
"src/AiHostLab131223/Components/Pages/Hardware.razor",
"src/AiHostLab131223/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab131223/Components/Pages/Logs.razor",
"src/AiHostLab131223/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab131223/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab131223/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab131223/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab131223/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab131223/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab131223/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab131223/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab131223/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab131223/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab131223/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab131223/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab131223/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab131223/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab131223/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab131223/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab131223/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab131223/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab131223.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab131223/AiHostLab131223.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab131223/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab131223/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab131223/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab131223/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab131223/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab131223/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab131223/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab131223/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab131223/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab131223/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab131223/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab131223/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab131223/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab131223/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab131223/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Generate a downloadable whole solution zip for a provider-neutral AI host replacement in .NET 10, ASP.NET Core, Blazor, and DevExpress. It must include model catalog, chat, downloads, running models, API console, logs, settings, templates, hardware, runner/plugins, /api/version, /api/tags, /api/ps, /api/chat, /api/generate, OpenAI-compatible routes, direct local model-file runner interfaces, Python.NET/PowerShell extension boundaries, and SQLite/appsettings state.

## Council Summary

Benchmark answer: create a buildable AI-host replacement solution zip with DevExpress pages, provider-compatible routes, runner/plugin service contracts, and no Go dependency. Include Implementation artifact request.