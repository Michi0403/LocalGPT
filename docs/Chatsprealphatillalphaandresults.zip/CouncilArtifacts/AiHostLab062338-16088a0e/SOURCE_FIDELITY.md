# Source Fidelity

Generated project: `AiHostLab062338`

## Acceptance Rule

A generated solution is not accepted merely because it compiles. It must preserve the requested source application's recognizable workflows, navigation, service boundaries, persistence shape, diagnostics, and download/artifact behavior.

## Expected Shape

An AI-host replacement must expose provider-compatible API routes, catalog/download/running-model UX, chat/API console, logs, settings, templates, hardware policy, runner/plugin boundaries, and direct local model-file inference without upstream proxying.

## Dynamic Promise Modules

- `/document-exports` / `DocumentExports.razor`: Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services.
- `/model-host-status` / `ModelHostStatus.razor`: Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status.
- `/persistence` / `Persistence.razor`: Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge.
- `/devexpress-ui` / `DevExpressUI.razor`: Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification.
- `/api-contracts` / `APIContracts.razor`: Promise-derived surface for backend routes, request/response DTOs, validation, errors, and smoke-test calls.

## Review Files

- `src/AiHostLab062338/Components/Pages/SourceFidelity.razor`
- `src/AiHostLab062338/Services/GeneratedSourceFidelityService.cs`
- `PROJECT_INDEX.md`
- `.localgpt-generation.json`
- `ARCHITECTURE.md`

## Benchmark Guidance

LocalGPT replacement benchmarks should inspect this file and the generated source-fidelity service before awarding architecture points. A page-only solution should score low when it misses source workflows, service contracts, or persistence boundaries.

## Integration Rule

This remains a sandbox artifact. Copying generated files into a real repo requires explicit user approval, a build, and a focused smoke test.