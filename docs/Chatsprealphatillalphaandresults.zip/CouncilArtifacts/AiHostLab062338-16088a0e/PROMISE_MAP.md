# Promise Map

Generated project: `AiHostLab062338`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/model-host-status` | `ModelHostStatus.razor` | Promise-derived surface for local model/provider inventory, host reachability, selected model, and runtime status. | Provider, Model catalog, Reachability, Runtime status |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |
| `/devexpress-ui` | `DevExpressUI.razor` | Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification. | Navigation, Grid, Form, Frontend smoke |
| `/api-contracts` | `APIContracts.razor` | Promise-derived surface for backend routes, request/response DTOs, validation, errors, and smoke-test calls. | Routes, DTOs, Validation, Smoke tests |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Potential:** Without adequate unit tests, regressions could occur. **Needs Verification / Open Questions:** * **Obfuscation Namespace:** Please confirm the intended namespace for the separated obfuscation methods (defaulting to `AgentObfuscationUtilities` if no response). * **Complete Changeset:** Confirm this upload represents a complete changeset since the last known version in our knowledge base. * **Logging Coverage:** Verify that logging is consistently applied across all relevant components and receives an `ILogger<T>` via constructor dependency injection, replacing any manual logger creation. **Current LocalGPT Behavior & Facts:** * The project is a Blazor/ASP.NET Core web app wrapped in WinUI 3 WebView2. * Logging appears to be implemented using `ILogger<T>`. * Obfuscation logic has been extracted into separate methods. * Build logs show no compilation errors (only Unicode warnings). **Proposed Future Improvements:** * **Unit Test Coverage:** Add comprehensive unit tests for the obfuscation helpers. * **Performance Benchmark:** Run a benchmark of the rogue Agent before/after refactor to quantify any overhead. * **Security Audit:** Verify that extracted methods do not expose...
```

## Council Excerpt

```text
**LocalGPT AI Council Consensus – Summary of Findings & Next‑Step Plan** --- ### Final Answer The uploaded source bundle is fully readable and contains the latest changes you described: logging has been added throughout, most obfuscation logic was moved into a dedicated helper namespace (currently `AgentObfuscationUtilities`), and many classes have been converted to static helpers. Controllers remain partially refactored and lack consistent logging or error handling. Regex‑based replacements still exist in several places, and hard‑coded “magic” values are still present. We agree on the following permanent guidance: 1. **Logging** – Use selective `LogLevel` thresholds; wrap every public method in a `try…catch` that logs *after* the exception is caught (not as a replacement). 2. **Regex → String Replacement** – Prefer `string.Replace`, `StartsWith/EndsWith`, etc., over `Regex` when possible for performance and clarity. 3. **Static Refactoring** – Document static helpers’ contracts; avoid hidden mutable state, use thread‑safe singletons or scoped services where needed. 4. **Security Guards** – Any backend call that can alter data or invoke dangerous operations must be gated by a front‑end confirmation dialog (user consent). 5. **SQLite Extension** – Add tables/columns to store obfuscation metadata and enable SQL prompt generation for new structures. --- ### Implementation Steps | Step | Action | Owner | |------|--------|-------| | 1 | **Audit Logging** – Scan all `.cs` files, ensure every `ILogger<T>` is injected via constructor; add missing DI registrations. | Council (all) |...
```