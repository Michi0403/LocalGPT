# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab062338/Program.cs",
    "src/AiHostLab062338/Components/Pages/Index.razor",
    "src/AiHostLab062338/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab062338/Components/Pages/SourceFidelity.razor",
"src/AiHostLab062338/Components/Pages/Chat.razor",
"src/AiHostLab062338/Components/Pages/RunningModels.razor",
"src/AiHostLab062338/Components/Pages/ModelDownloads.razor",
"src/AiHostLab062338/Components/Pages/Templates.razor",
"src/AiHostLab062338/Components/Pages/Hardware.razor",
"src/AiHostLab062338/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab062338/Components/Pages/Logs.razor",
"src/AiHostLab062338/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab062338/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab062338/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab062338/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab062338/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab062338/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab062338/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab062338/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab062338/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab062338/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab062338/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab062338/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab062338/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab062338/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab062338/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab062338/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab062338/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab062338/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab062338.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab062338/AiHostLab062338.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab062338/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab062338/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab062338/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab062338/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab062338/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab062338/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab062338/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab062338/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab062338/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab062338/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab062338/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab062338/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab062338/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab062338/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab062338/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Potential:** Without adequate unit tests, regressions could occur. **Needs Verification / Open Questions:** * **Obfuscation Namespace:** Please confirm the intended namespace for the separated obfuscation methods (defaulting to `AgentObfuscationUtilities` if no response). * **Complete Changeset:** Confirm this upload represents a complete changeset since the last known version in our knowledge base. * **Logging Coverage:** Verify that logging is consistently applied across all relevant components and receives an `ILogger<T>` via constructor dependency injection, replacing any manual logger creation. **Current LocalGPT Behavior & Facts:** * The project is a Blazor/ASP.NET Core web app wrapped in WinUI 3 WebView2. * Logging appears to be implemented using `ILogger<T>`. * Obfuscation logic has been extracted into separate methods. * Build logs show no compilation errors (only Unicode warnin...

## Council Summary

**LocalGPT AI Council Consensus – Summary of Findings & Next‑Step Plan** --- ### Final Answer The uploaded source bundle is fully readable and contains the latest changes you described: logging has been added throughout, most obfuscation logic was moved into a dedicated helper namespace (currently `AgentObfuscationUtilities`), and many classes have been converted to static helpers. Controllers remain partially refactored and lack consistent logging or error handling. Regex‑based replacements still exist in several places, and hard‑coded “magic” values are still present. We agree on the following permanent guidance: 1. **Logging** – Use selective `LogLevel` thresholds; wrap every public method in a `try…catch` that logs *after* the exception is caught (not as a replacement). 2. **Regex → String Replacement** – Prefer `string.Replace`, `StartsWith/EndsWith`, etc., over `Regex` when possibl...