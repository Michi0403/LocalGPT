using DevExpress.Blazor;
using Microsoft.AspNetCore.Mvc;
using BotBackend131228.Components;
using BotBackend131228.Models;
using BotBackend131228.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddDevExpressBlazor(options => options.SizeMode = SizeMode.Small);
builder.Services.AddSingleton<GeneratedHealthSummaryService>();
builder.Services.AddSingleton<ISourceFidelityService, GeneratedSourceFidelityService>();


var app = builder.Build();

app.UseStaticFiles();
app.UseAntiforgery();
app.MapGet("/__generated/health", (GeneratedHealthSummaryService service) => service.GetCards());

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();