# Source Fidelity

Generated project: `BotBackend131228`

## Acceptance Rule

A generated solution is not accepted merely because it compiles. It must preserve the requested source application's recognizable workflows, navigation, service boundaries, persistence shape, diagnostics, and download/artifact behavior.

## Expected Shape

A bot backend replacement must expose webhook ingress, conversation state, command routing, moderation/retry queues, settings/logs, optional Python interop, and permission gates.

## Dynamic Promise Modules

- `/document-exports` / `DocumentExports.razor`: Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services.
- `/persistence` / `Persistence.razor`: Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge.
- `/devexpress-ui` / `DevExpressUI.razor`: Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification.

## Review Files

- `src/BotBackend131228/Components/Pages/SourceFidelity.razor`
- `src/BotBackend131228/Services/GeneratedSourceFidelityService.cs`
- `PROJECT_INDEX.md`
- `.localgpt-generation.json`
- `ARCHITECTURE.md`

## Benchmark Guidance

LocalGPT replacement benchmarks should inspect this file and the generated source-fidelity service before awarding architecture points. A page-only solution should score low when it misses source workflows, service contracts, or persistence boundaries.

## Integration Rule

This remains a sandbox artifact. Copying generated files into a real repo requires explicit user approval, a build, and a focused smoke test.