# Project Index

## Purpose

Prototype a LocalGPT/TacosPortalOpen-style AI Council feature workspace with reviewable Blazor pages.

## Archetype

```json
{
  "project_kind": "localgpt_feature",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": false,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/BotBackend131228/Program.cs",
    "src/BotBackend131228/Components/Pages/Index.razor",
    "src/BotBackend131228/Components/Pages/GeneratedDashboard.razor",
    "src/BotBackend131228/Components/Pages/SourceFidelity.razor"
  ]
}
```

## Entry Points

- `src/BotBackend131228/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/BotBackend131228/Components/App.razor` - document shell and static asset links.
- `src/BotBackend131228/Components/Routes.razor` - Blazor route discovery.
- `src/BotBackend131228/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/BotBackend131228/Components/Pages/Index.razor` - first viewport and page hub.
- `src/BotBackend131228/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/BotBackend131228/Components/Pages/GeneratedKnowledgeTable.razor route `/knowledge`` - archetype catalog page.
- `src/BotBackend131228/Components/Pages/ImplementationPlan.razor route `/implementation-plan`` - archetype-specific detail page.
- `src/BotBackend131228/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.


## Generated Files

| File | Why it exists |
| --- | --- |
| `BotBackend131228.sln` | Visual Studio and CLI solution entry point. |
| `src/BotBackend131228/BotBackend131228.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/BotBackend131228/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/BotBackend131228/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/BotBackend131228/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |

| `src/BotBackend131228/wwwroot/app.css` | Local styling for the generated shell. |
| `src/BotBackend131228/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/BotBackend131228/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Generate a downloadable whole solution zip for a simpler bot backend inspired by legacy Telegram-style integrations, but sanitized. It must include webhooks, conversation state, command routing, moderation/retry queues, optional Python.NET boundary for speech/translation/media helpers, settings, logs, EF/SQLite, and a DevExpress Blazor operator UI.

## Council Summary

Benchmark answer: create a simple bot backend solution zip with webhook/conversation/settings/python-interop pages and safe backend service boundaries. Include Implementation artifact request.