using System.Text.Json.Serialization;

namespace LocalGptLab131157.Models;

/// <summary>
/// Describes one status card rendered by the generated LocalGPT workbench.
/// </summary>
public sealed class GeneratedHealthCard
{
    /// <summary>
    /// Creates a generated health card.
    /// </summary>
    public GeneratedHealthCard(string area, string status, string nextAction, string detail)
    {
        Area = area;
        Status = status;
        NextAction = nextAction;
        Detail = detail;
    }

    /// <summary>
    /// Gets the subsystem or concern represented by the card.
    /// </summary>
    public string Area { get; }

    /// <summary>
    /// Gets the current generated status.
    /// </summary>
    public string Status { get; }

    /// <summary>
    /// Gets the next suggested action.
    /// </summary>
    public string NextAction { get; }

    /// <summary>
    /// Gets the implementation detail shown in expanded views.
    /// </summary>
    public string Detail { get; }
}

/// <summary>
/// Describes one model or adapter row in the generated AI host control-plane lab.
/// </summary>
public sealed class GeneratedModelCard
{
    /// <summary>
    /// Creates a generated model compatibility row.
    /// </summary>
    public GeneratedModelCard(string name, string status, long sizeMegabytes, bool supportsNativeInference)
    {
        Name = name;
        Status = status;
        SizeMegabytes = sizeMegabytes;
        SupportsNativeInference = supportsNativeInference;
    }

    /// <summary>
    /// Gets the model, adapter, or backend name.
    /// </summary>
    public string Name { get; }

    /// <summary>
    /// Gets the current compatibility status.
    /// </summary>
    public string Status { get; }

    /// <summary>
    /// Gets the sample size in megabytes, or zero when the lab does not own a model binary.
    /// </summary>
    public long SizeMegabytes { get; }

    /// <summary>
    /// Gets whether this row represents a real native inference path.
    /// </summary>
    public bool SupportsNativeInference { get; }
}

/// <summary>
/// Describes an API endpoint or implementation step in the generated solution.
/// </summary>
public sealed class GeneratedEndpointCard
{
    /// <summary>
    /// Creates a generated endpoint or workflow row.
    /// </summary>
    public GeneratedEndpointCard(string method, string route, string purpose, string boundary)
    {
        Method = method;
        Route = route;
        Purpose = purpose;
        Boundary = boundary;
    }

    /// <summary>
    /// Gets the HTTP method or ordered workflow step.
    /// </summary>
    public string Method { get; }

    /// <summary>
    /// Gets the route, owner, or target area.
    /// </summary>
    public string Route { get; }

    /// <summary>
    /// Gets the row purpose.
    /// </summary>
    public string Purpose { get; }

    /// <summary>
    /// Gets the safety or implementation boundary.
    /// </summary>
    public string Boundary { get; }
}

/// <summary>
/// Describes one AI-host-compatible model row returned by generated catalog routes.
/// </summary>
public sealed class GeneratedAiHostModelTag
{
    /// <summary>
    /// Creates a generated AI-host-compatible model row.
    /// </summary>
    public GeneratedAiHostModelTag(
        string name,
        string family,
        string parameterSize,
        string quantizationLevel,
        long size)
    {
        Name = name;
        Model = name;
        ModifiedAt = DateTimeOffset.UtcNow;
        Size = size;
        Digest = $"generated-{Math.Abs(name.GetHashCode(StringComparison.Ordinal)):x}";
        Details = new GeneratedAiHostModelDetails("gguf", family, parameterSize, quantizationLevel);
    }

    /// <summary>
    /// Gets the provider-compatible model name field.
    /// </summary>
    [JsonPropertyName("name")]
    public string Name { get; }

    /// <summary>
    /// Gets the model identifier.
    /// </summary>
    [JsonPropertyName("model")]
    public string Model { get; }

    /// <summary>
    /// Gets the generated modification timestamp.
    /// </summary>
    [JsonPropertyName("modified_at")]
    public DateTimeOffset ModifiedAt { get; }

    /// <summary>
    /// Gets the generated model size in bytes.
    /// </summary>
    [JsonPropertyName("size")]
    public long Size { get; }

    /// <summary>
    /// Gets a deterministic generated digest placeholder.
    /// </summary>
    [JsonPropertyName("digest")]
    public string Digest { get; }

    /// <summary>
    /// Gets model detail metadata.
    /// </summary>
    [JsonPropertyName("details")]
    public GeneratedAiHostModelDetails Details { get; }
}

/// <summary>
/// Describes generated AI-host-compatible model details.
/// </summary>
public sealed class GeneratedAiHostModelDetails
{
    /// <summary>
    /// Creates generated model details.
    /// </summary>
    public GeneratedAiHostModelDetails(
        string format,
        string family,
        string parameterSize,
        string quantizationLevel)
    {
        Format = format;
        Family = family;
        Families = [family];
        ParameterSize = parameterSize;
        QuantizationLevel = quantizationLevel;
    }

    /// <summary>
    /// Gets the generated model file format.
    /// </summary>
    [JsonPropertyName("format")]
    public string Format { get; }

    /// <summary>
    /// Gets the generated primary model family.
    /// </summary>
    [JsonPropertyName("family")]
    public string Family { get; }

    /// <summary>
    /// Gets generated model families.
    /// </summary>
    [JsonPropertyName("families")]
    public IReadOnlyList<string> Families { get; }

    /// <summary>
    /// Gets the generated parameter size label.
    /// </summary>
    [JsonPropertyName("parameter_size")]
    public string ParameterSize { get; }

    /// <summary>
    /// Gets the generated quantization label.
    /// </summary>
    [JsonPropertyName("quantization_level")]
    public string QuantizationLevel { get; }
}

/// <summary>
/// Represents a generated AI host action request.
/// </summary>
public sealed class GeneratedModelActionRequest
{
    /// <summary>
    /// Gets or sets the model name.
    /// </summary>
    [JsonPropertyName("model")]
    public string? Model { get; set; }

    /// <summary>
    /// Gets or sets the prompt for generate/embed-style routes.
    /// </summary>
    [JsonPropertyName("prompt")]
    public string? Prompt { get; set; }

    /// <summary>
    /// Gets or sets whether the caller requested streaming.
    /// </summary>
    [JsonPropertyName("stream")]
    public bool Stream { get; set; }

    /// <summary>
    /// Gets or sets Ollama-compatible request options.
    /// </summary>
    [JsonPropertyName("options")]
    public GeneratedRequestOptions? Options { get; set; }
}

/// <summary>
/// Represents Ollama-compatible request options accepted by the generated host.
/// </summary>
public sealed class GeneratedRequestOptions
{
    /// <summary>
    /// Gets or sets the requested context token budget.
    /// </summary>
    [JsonPropertyName("num_ctx")]
    public int? NumCtx { get; set; }

    /// <summary>
    /// Gets or sets the requested output token budget.
    /// </summary>
    [JsonPropertyName("num_predict")]
    public int? NumPredict { get; set; }

    /// <summary>
    /// Gets or sets the requested GPU layer count.
    /// </summary>
    [JsonPropertyName("num_gpu")]
    public int? NumGpu { get; set; }

    /// <summary>
    /// Gets or sets the requested sampling temperature.
    /// </summary>
    [JsonPropertyName("temperature")]
    public float? Temperature { get; set; }
}

/// <summary>
/// Represents a generated AI host copy request.
/// </summary>
public sealed class GeneratedModelCopyRequest
{
    /// <summary>
    /// Gets or sets the source model.
    /// </summary>
    [JsonPropertyName("source")]
    public string? Source { get; set; }

    /// <summary>
    /// Gets or sets the destination model.
    /// </summary>
    [JsonPropertyName("destination")]
    public string? Destination { get; set; }
}

/// <summary>
/// Represents a generated AI host chat request.
/// </summary>
public sealed class GeneratedChatRequest
{
    /// <summary>
    /// Gets or sets the requested model.
    /// </summary>
    [JsonPropertyName("model")]
    public string? Model { get; set; }

    /// <summary>
    /// Gets or sets the chat messages.
    /// </summary>
    [JsonPropertyName("messages")]
    public List<GeneratedChatMessage> Messages { get; set; } = [];

    /// <summary>
    /// Gets or sets whether the caller requested streaming.
    /// </summary>
    [JsonPropertyName("stream")]
    public bool Stream { get; set; }

    /// <summary>
    /// Gets or sets Ollama-compatible request options.
    /// </summary>
    [JsonPropertyName("options")]
    public GeneratedRequestOptions? Options { get; set; }
}

/// <summary>
/// Represents a generated AI host chat message.
/// </summary>
public sealed class GeneratedChatMessage
{
    /// <summary>
    /// Creates an empty generated chat message.
    /// </summary>
    public GeneratedChatMessage()
    {
    }

    /// <summary>
    /// Creates a generated chat message.
    /// </summary>
    public GeneratedChatMessage(string role, string content)
    {
        Role = role;
        Content = content;
    }

    /// <summary>
    /// Gets or sets the chat role.
    /// </summary>
    [JsonPropertyName("role")]
    public string Role { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the chat content.
    /// </summary>
    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;
}

/// <summary>
/// Represents a generated AI host chat response with typed properties for Razor and service code.
/// </summary>
public sealed class GeneratedChatResponse
{
    /// <summary>
    /// Creates a generated chat response.
    /// </summary>
    public GeneratedChatResponse(
        string model,
        DateTimeOffset createdAt,
        GeneratedChatMessage message,
        bool done)
    {
        Model = model;
        CreatedAt = createdAt;
        Message = message;
        Done = done;
    }

    /// <summary>
    /// Gets the model name used by the generated response.
    /// </summary>
    [JsonPropertyName("model")]
    public string Model { get; }

    /// <summary>
    /// Gets the generated response timestamp.
    /// </summary>
    [JsonPropertyName("created_at")]
    public DateTimeOffset CreatedAt { get; }

    /// <summary>
    /// Gets the generated assistant message.
    /// </summary>
    [JsonPropertyName("message")]
    public GeneratedChatMessage Message { get; }

    /// <summary>
    /// Gets whether the generated response is complete.
    /// </summary>
    [JsonPropertyName("done")]
    public bool Done { get; }
}

/// <summary>
/// Describes a generated model download planning row.
/// </summary>
public sealed class GeneratedModelDownloadCandidate
{
    /// <summary>
    /// Creates a generated download candidate.
    /// </summary>
    public GeneratedModelDownloadCandidate(
        string name,
        string sourceType,
        string sourceUrl,
        string recommendedFor,
        string downloadRoute,
        string safetyNote)
    {
        Name = name;
        SourceType = sourceType;
        SourceUrl = sourceUrl;
        RecommendedFor = recommendedFor;
        DownloadRoute = downloadRoute;
        SafetyNote = safetyNote;
    }

    /// <summary>
    /// Gets the candidate model name.
    /// </summary>
    public string Name { get; }

    /// <summary>
    /// Gets the catalog or provider type.
    /// </summary>
    public string SourceType { get; }

    /// <summary>
    /// Gets the catalog URL or provider base URI.
    /// </summary>
    public string SourceUrl { get; }

    /// <summary>
    /// Gets the recommended use case.
    /// </summary>
    public string RecommendedFor { get; }

    /// <summary>
    /// Gets the route used to plan the download.
    /// </summary>
    public string DownloadRoute { get; }

    /// <summary>
    /// Gets the safety note for the generated lab.
    /// </summary>
    public string SafetyNote { get; }
}

/// <summary>
/// Holds generated AI host lab settings shown in the DevExpress form.
/// </summary>
public sealed class GeneratedAiHostSettings
{
    /// <summary>
    /// Gets or sets the local model source summary.
    /// </summary>
    public string BaseUri { get; set; } = "native local model files";

    /// <summary>
    /// Gets or sets the default model for generated request examples.
    /// </summary>
    public string DefaultModel { get; set; } = "gpt-oss:20b";

    /// <summary>
    /// Gets or sets the generated keep-alive value.
    /// </summary>
    public string KeepAlive { get; set; } = "5m";

    /// <summary>
    /// Gets or sets the generated context token budget.
    /// </summary>
    public int ContextTokens { get; set; } = 2048;

    /// <summary>
    /// Gets or sets the generated GPU layer budget.
    /// </summary>
    public int GpuLayers { get; set; } = 0;

    /// <summary>
    /// Gets or sets whether a native runner is attached.
    /// </summary>
    public bool NativeRunnerAttached { get; set; }

    /// <summary>
    /// Gets or sets whether pull planning is enabled.
    /// </summary>
    public bool AllowPullPlanning { get; set; } = true;
}

/// <summary>
/// Describes a generated AI-host-compatible operation result.
/// </summary>
public sealed class GeneratedAiHostOperation
{
    /// <summary>
    /// Creates a generated operation result.
    /// </summary>
    public GeneratedAiHostOperation(
        string status,
        string model,
        string route,
        bool done,
        string detail)
    {
        Status = status;
        Model = model;
        Route = route;
        Done = done;
        Detail = detail;
    }

    /// <summary>
    /// Gets the generated operation status.
    /// </summary>
    [JsonPropertyName("status")]
    public string Status { get; }

    /// <summary>
    /// Gets the affected model or model mapping.
    /// </summary>
    [JsonPropertyName("model")]
    public string Model { get; }

    /// <summary>
    /// Gets the route that produced the result.
    /// </summary>
    [JsonPropertyName("route")]
    public string Route { get; }

    /// <summary>
    /// Gets whether the generated operation is complete.
    /// </summary>
    [JsonPropertyName("done")]
    public bool Done { get; }

    /// <summary>
    /// Gets the generated explanation.
    /// </summary>
    [JsonPropertyName("detail")]
    public string Detail { get; }
}