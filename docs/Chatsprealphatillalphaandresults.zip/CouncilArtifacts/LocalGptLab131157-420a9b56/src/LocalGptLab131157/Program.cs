using DevExpress.Blazor;
using Microsoft.AspNetCore.Mvc;
using LocalGptLab131157.Components;
using LocalGptLab131157.Models;
using LocalGptLab131157.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddDevExpressBlazor(options => options.SizeMode = SizeMode.Small);
builder.Services.AddSingleton<GeneratedHealthSummaryService>();
builder.Services.AddSingleton<ISourceFidelityService, GeneratedSourceFidelityService>();


var app = builder.Build();

app.UseStaticFiles();
app.UseAntiforgery();
app.MapGet("/__generated/health", (GeneratedHealthSummaryService service) => service.GetCards());

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();