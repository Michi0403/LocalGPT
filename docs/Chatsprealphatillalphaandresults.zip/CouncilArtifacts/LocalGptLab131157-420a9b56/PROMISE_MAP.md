# Promise Map

Generated project: `LocalGptLab131157`

This file maps the user's request and the council's promised architecture into generated review surfaces. It exists so LocalGPT does not ship a generic shell after the council described a richer application.

## Dynamic Modules

| Route | File | Promise Preserved | Review Areas |
| --- | --- | --- | --- |
| `/document-exports` | `DocumentExports.razor` | Promise-derived surface for report, Office, PDF, spreadsheet, presentation, and document export work owned by backend services. | Report template, Format mapping, Backend service, Download route |
| `/persistence` | `Persistence.razor` | Promise-derived surface for database state, DTO projection, migration safety, audit records, and user-approved knowledge. | EF/SQLite, DTOs, Migration safety, Audit |
| `/devexpress-ui` | `DevExpressUI.razor` | Promise-derived surface for DevExpress Blazor controls, layout, navigation, forms, grids, and frontend verification. | Navigation, Grid, Form, Frontend smoke |

## Artifact Rule

A concrete downloadable target is not enough by itself. If the council creates a blocking user decision poll, artifact generation must pause until the user answers or grants safe sandbox auto-choice. If no blocking poll remains, the generated artifact should preserve the council's promised workflows in pages, services, docs, and validation notes.

## Request Excerpt

```text
Generate a downloadable whole solution zip for a DevExpress Blazor webshop with EF Core, SQLite seed data, products, carts, orders, admin CRUD grid, detail form, Bootstrap v5 layout, and README.
```

## Council Excerpt

```text
Benchmark answer: create a full solution zip with DevExpress Blazor pages, EF Core entities, services, product/cart/order workflows, and README. Include Implementation artifact request.
```