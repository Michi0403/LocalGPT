# Project Index

## Purpose

Prototype a LocalGPT/TacosPortalOpen-style AI Council feature workspace with reviewable Blazor pages.

## Archetype

```json
{
  "project_kind": "localgpt_feature",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": false,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/LocalGptLab131157/Program.cs",
    "src/LocalGptLab131157/Components/Pages/Index.razor",
    "src/LocalGptLab131157/Components/Pages/GeneratedDashboard.razor",
    "src/LocalGptLab131157/Components/Pages/SourceFidelity.razor"
  ]
}
```

## Entry Points

- `src/LocalGptLab131157/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/LocalGptLab131157/Components/App.razor` - document shell and static asset links.
- `src/LocalGptLab131157/Components/Routes.razor` - Blazor route discovery.
- `src/LocalGptLab131157/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/LocalGptLab131157/Components/Pages/Index.razor` - first viewport and page hub.
- `src/LocalGptLab131157/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/LocalGptLab131157/Components/Pages/GeneratedKnowledgeTable.razor route `/knowledge`` - archetype catalog page.
- `src/LocalGptLab131157/Components/Pages/ImplementationPlan.razor route `/implementation-plan`` - archetype-specific detail page.
- `src/LocalGptLab131157/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.


## Generated Files

| File | Why it exists |
| --- | --- |
| `LocalGptLab131157.sln` | Visual Studio and CLI solution entry point. |
| `src/LocalGptLab131157/LocalGptLab131157.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/LocalGptLab131157/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/LocalGptLab131157/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/LocalGptLab131157/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |

| `src/LocalGptLab131157/wwwroot/app.css` | Local styling for the generated shell. |
| `src/LocalGptLab131157/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/LocalGptLab131157/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Generate a downloadable whole solution zip for a DevExpress Blazor webshop with EF Core, SQLite seed data, products, carts, orders, admin CRUD grid, detail form, Bootstrap v5 layout, and README.

## Council Summary

Benchmark answer: create a full solution zip with DevExpress Blazor pages, EF Core entities, services, product/cart/order workflows, and README. Include Implementation artifact request.