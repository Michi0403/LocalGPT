# Build And Run

## Requirements

- .NET 10 SDK
- DevExpress Blazor 25.1 package feed/license access
- Visual Studio 2026 or `dotnet` CLI

## Commands

```powershell
dotnet restore
dotnet build
dotnet run --project .\src\LocalGptLab131157\LocalGptLab131157.csproj
```

## Expected Checks

- `/` shows the generated index page with navigation.
- `/dashboard` shows the generated health/status grid.
- `/source-fidelity` shows source-signal, boundary, status, and evidence rows.
- Open `/implementation-plan` and verify implementation steps are visible.
- `PROJECT_INDEX.md` and `.localgpt-generation.json` describe the selected archetype.

## Validation Honesty

Do not claim build success unless `dotnet build` completed and the command output is available. Do not claim production readiness; this zip is a sandbox artifact.