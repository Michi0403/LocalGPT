using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using AiHostLab055635.Models;

#pragma warning disable CS1591 // Generated sandbox contracts are documented in ARCHITECTURE.md and BUILD_AND_RUN.md.

namespace AiHostLab055635.Services;

/// <summary>
/// Typed bootstrap settings for a generated provider-compatible AI host control plane.
/// Persist user-edited runtime values in SQLite when this lab becomes a real app.
/// </summary>
public sealed class AiHostRuntimeOptions
{
    public string DefaultModel { get; set; } = "gpt-oss:20b";
    public string SafeStorageRoot { get; set; } = "%LOCALAPPDATA%/GeneratedAiHost";
    public string PluginRoot { get; set; } = "plugins";
    public string? PythonDll { get; set; }
    public string NativeRunnerExecutable { get; set; } = string.Empty;
    public List<string> ModelSearchRoots { get; set; } = new();
    public Dictionary<string, string> ModelFileOverrides { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int ContextTokens { get; set; } = 2048;
    public int GpuLayers { get; set; } = 20;
    public bool AllowNativeRunner { get; set; } = true;
    public bool AllowPythonNet { get; set; }
    public bool AllowPowerShellScripts { get; set; }
    public bool AllowTypeScriptAdapters { get; set; }
}

public interface IModelCatalogService
{
    IReadOnlyList<GeneratedAiHostModelTag> GetAiHostTags();
    IReadOnlyList<GeneratedAiHostModelTag> GetRunningModels();
    object GetModelDetails(GeneratedModelActionRequest request);
}

public interface IModelTransferService
{
    GeneratedAiHostOperation CreatePullPlan(GeneratedModelActionRequest request);
}

public interface IInferenceProvider
{
    string ProviderKind { get; }
    Task<GeneratedChatResponse> ChatAsync(GeneratedChatRequest request, CancellationToken cancellationToken = default);
    Task<object> GenerateAsync(GeneratedModelActionRequest request, CancellationToken cancellationToken = default);
}

public interface IInferenceRunner
{
    string RunnerKind { get; }
    Task<RunnerCapabilityReport> GetCapabilityAsync(CancellationToken cancellationToken = default);
    Task<GeneratedChatResponse> InferAsync(GeneratedChatRequest request, CancellationToken cancellationToken = default);
}

public interface IPluginCatalogService
{
    IReadOnlyList<AiHostPluginManifest> GetPlugins();
}

public interface IScriptExecutionService
{
    ScriptExecutionPlan CreatePlan(string scriptKind, string target, bool userApproved);
}

public interface IHardwareBudgetService
{
    HardwareBudgetSnapshot GetBudget();
}

public interface IChatTemplateService
{
    IReadOnlyList<ChatTemplateRule> GetTemplateRules();
}

/// <summary>
/// Routes provider-compatible requests to the generated host's own local-file runner.
/// This class intentionally does not call an upstream Ollama/LM Studio/OpenAI endpoint.
/// </summary>
public sealed class NativeModelFileInferenceProvider(
    IInferenceRunner runner,
    IOptions<AiHostRuntimeOptions> options) : IInferenceProvider
{
    public string ProviderKind => "Native local-model-file provider";

    public async Task<GeneratedChatResponse> ChatAsync(GeneratedChatRequest request, CancellationToken cancellationToken = default)
    {
        request.Model = NormalizeModel(request.Model, options.Value.DefaultModel);
        return await runner.InferAsync(request, cancellationToken);
    }

    public async Task<object> GenerateAsync(GeneratedModelActionRequest request, CancellationToken cancellationToken = default)
    {
        var prompt = string.IsNullOrWhiteSpace(request.Prompt)
            ? "LocalGPT generated AI host native-runner smoke test."
            : request.Prompt;
        var chat = new GeneratedChatRequest
        {
            Model = NormalizeModel(request.Model, options.Value.DefaultModel),
            Messages = new List<GeneratedChatMessage>
            {
                new("user", prompt)
            },
            Stream = request.Stream,
            Options = request.Options
        };
        var response = await runner.InferAsync(chat, cancellationToken);
        return new
        {
            model = response.Model,
            created_at = response.CreatedAt,
            response = response.Message.Content,
            done = response.Done,
            upstream_proxy = false
        };
    }

    public static string NormalizeModel(string? model, string fallbackModel)
    {
        return string.IsNullOrWhiteSpace(model)
            ? fallbackModel
            : model.Trim();
    }
}

/// <summary>
/// Loads compatible local model files through an approved native executable.
/// Ollama manifests may be read as local file metadata, but the Ollama service is never called.
/// </summary>
public sealed class NativeModelFileProcessRunner(IOptions<AiHostRuntimeOptions> options) : IInferenceRunner
{
    public string RunnerKind => "Native model-file process runner";

    public Task<RunnerCapabilityReport> GetCapabilityAsync(CancellationToken cancellationToken = default)
    {
        var executable = ExpandPath(options.Value.NativeRunnerExecutable);
        var executableReady = options.Value.AllowNativeRunner &&
            !string.IsNullOrWhiteSpace(executable) &&
            File.Exists(executable);

        return Task.FromResult(new RunnerCapabilityReport(
            NativeInferenceImplemented: executableReady,
            SupportedFormats: ["gguf", "ollama-managed-gguf-blob", "onnx-planned", "safetensors-planned"],
            MissingCapability: executableReady
                ? string.Empty
                : "Set AiHost:NativeRunnerExecutable to an approved native runner such as llama-cli/llama-server before chat/generate can execute model files.",
            NextMilestone: "Configure NativeRunnerExecutable and ModelSearchRoots, verify /api/localgpt/runner/capability, then point LocalGPT DXAiChat at this host URL."));
    }

    public async Task<GeneratedChatResponse> InferAsync(GeneratedChatRequest request, CancellationToken cancellationToken = default)
    {
        var model = NormalizeModel(request.Model, options.Value.DefaultModel);
        if (!options.Value.AllowNativeRunner)
            return BuildStatusResponse(model, "Native runner execution is disabled by AiHost:AllowNativeRunner. No upstream proxy fallback is used.");

        var executable = ExpandPath(options.Value.NativeRunnerExecutable);
        if (string.IsNullOrWhiteSpace(executable) || !File.Exists(executable))
            return BuildStatusResponse(model, "Native runner executable is not configured. Set AiHost:NativeRunnerExecutable to a trusted llama.cpp-compatible runner. No upstream proxy fallback is used.");

        var modelPath = ResolveModelPath(model);
        if (string.IsNullOrWhiteSpace(modelPath))
            return BuildStatusResponse(model, $"Could not resolve a compatible local model file for '{model}'. Add a ModelFileOverrides entry or a .gguf file under ModelSearchRoots. No upstream proxy fallback is used.");

        var prompt = BuildPrompt(request);
        var arguments = BuildRunnerArguments(modelPath, prompt, request.Options);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromMinutes(20));

        var startInfo = new ProcessStartInfo(executable)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            WorkingDirectory = Path.GetDirectoryName(executable) ?? AppContext.BaseDirectory
        };

        foreach (var argument in arguments)
            startInfo.ArgumentList.Add(argument);

        using var process = Process.Start(startInfo);
        if (process is null)
            return BuildStatusResponse(model, "The native runner process could not be started.");

        try
        {
            var outputTask = process.StandardOutput.ReadToEndAsync(timeout.Token);
            var errorTask = process.StandardError.ReadToEndAsync(timeout.Token);
            await process.WaitForExitAsync(timeout.Token);
            var output = await outputTask;
            var error = await errorTask;
            var visible = string.IsNullOrWhiteSpace(output)
                ? $"Native runner exited with code {process.ExitCode}. {error}".Trim()
                : output.Trim();

            return new GeneratedChatResponse(
                model,
                DateTimeOffset.UtcNow,
                new GeneratedChatMessage("assistant", visible),
                true);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            TryKill(process);
            return BuildStatusResponse(model, "Native runner timed out after 20 minutes. Reduce context/output tokens or use a smaller model.");
        }
    }

    private string? ResolveModelPath(string model)
    {
        if (options.Value.ModelFileOverrides.TryGetValue(model, out var configuredPath))
        {
            var expanded = ExpandPath(configuredPath);
            if (File.Exists(expanded))
                return expanded;
        }

        foreach (var root in options.Value.ModelSearchRoots.Select(ExpandPath).Where(Directory.Exists))
        {
            var direct = ResolveDirectGguf(root, model);
            if (!string.IsNullOrWhiteSpace(direct))
                return direct;

            var managed = ResolveOllamaManagedBlob(root, model);
            if (!string.IsNullOrWhiteSpace(managed))
                return managed;
        }

        return null;
    }

    public static string? ResolveDirectGguf(string root, string model)
    {
        var sanitized = model.Replace(':', '-').Replace('/', '-').Replace('\\', '-');
        foreach (var candidate in new[]
        {
            Path.Combine(root, $"{model}.gguf"),
            Path.Combine(root, $"{sanitized}.gguf"),
            Path.Combine(root, model, $"{sanitized}.gguf")
        })
        {
            if (File.Exists(candidate))
                return candidate;
        }

        try
        {
            return Directory.EnumerateFiles(root, "*.gguf", SearchOption.AllDirectories)
                .Take(2000)
                .FirstOrDefault(path => Path.GetFileNameWithoutExtension(path).Contains(sanitized, StringComparison.OrdinalIgnoreCase));
        }
        catch
        {
            return null;
        }
    }

    public static string? ResolveOllamaManagedBlob(string root, string model)
    {
        var (name, tag) = SplitModelName(model);
        var manifest = Path.Combine(root, "manifests", "registry.ollama.ai", "library", name, tag);
        if (!File.Exists(manifest) && Directory.Exists(Path.Combine(root, "manifests")))
        {
            manifest = Directory.EnumerateFiles(Path.Combine(root, "manifests"), tag, SearchOption.AllDirectories)
                .FirstOrDefault(path => Path.GetFileName(Path.GetDirectoryName(path) ?? string.Empty).Equals(name, StringComparison.OrdinalIgnoreCase))
                ?? string.Empty;
        }

        if (string.IsNullOrWhiteSpace(manifest) || !File.Exists(manifest))
            return null;

        try
        {
            using var document = JsonDocument.Parse(File.ReadAllText(manifest));
            if (!document.RootElement.TryGetProperty("layers", out var layers) || layers.ValueKind != JsonValueKind.Array)
                return null;

            return layers
                .EnumerateArray()
                .Select(layer => layer.TryGetProperty("digest", out var digest) ? digest.GetString() : null)
                .Where(digest => !string.IsNullOrWhiteSpace(digest))
                .Select(digest => Path.Combine(root, "blobs", digest!.Replace(':', '-')))
                .FirstOrDefault(File.Exists);
        }
        catch
        {
            return null;
        }
    }

    public static IReadOnlyList<string> BuildRunnerArguments(string modelPath, string prompt, GeneratedRequestOptions? requestOptions)
    {
        var ctx = Math.Clamp(requestOptions?.NumCtx ?? 2048, 256, 262144);
        var predict = Math.Clamp(requestOptions?.NumPredict ?? 1024, 1, 262144);
        var gpuLayers = Math.Clamp(requestOptions?.NumGpu ?? 0, 0, 999);
        var args = new List<string>
        {
            "--model", modelPath,
            "--prompt", prompt,
            "--ctx-size", ctx.ToString(CultureInfo.InvariantCulture),
            "--n-predict", predict.ToString(CultureInfo.InvariantCulture),
            "--gpu-layers", gpuLayers.ToString(CultureInfo.InvariantCulture)
        };

        if (requestOptions?.Temperature is { } temperature)
        {
            args.Add("--temp");
            args.Add(temperature.ToString(CultureInfo.InvariantCulture));
        }

        return args;
    }

    public static string BuildPrompt(GeneratedChatRequest request)
    {
        var builder = new StringBuilder();
        foreach (var message in request.Messages.Where(message => !string.IsNullOrWhiteSpace(message.Content)))
            builder.Append(message.Role ?? "user").Append(": ").AppendLine(message.Content);
        if (builder.Length == 0)
            builder.AppendLine("user: Hello");
        builder.Append("assistant: ");
        return builder.ToString();
    }

    public static (string Name, string Tag) SplitModelName(string model)
    {
        var parts = model.Split(':', 2, StringSplitOptions.TrimEntries);
        return (parts[0], parts.Length == 2 && !string.IsNullOrWhiteSpace(parts[1]) ? parts[1] : "latest");
    }

    public static string NormalizeModel(string? model, string fallbackModel)
    {
        return string.IsNullOrWhiteSpace(model)
            ? fallbackModel
            : model.Trim();
    }

    public static string ExpandPath(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return string.Empty;

        var expanded = path
            .Replace("%LOCALAPPDATA%", Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), StringComparison.OrdinalIgnoreCase)
            .Replace("%USERPROFILE%", Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), StringComparison.OrdinalIgnoreCase);

        return expanded.StartsWith("~/", StringComparison.Ordinal) || expanded.StartsWith("~\\", StringComparison.Ordinal)
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), expanded[2..])
            : expanded;
    }

    public static GeneratedChatResponse BuildStatusResponse(string model, string message)
    {
        return new GeneratedChatResponse(
            model,
            DateTimeOffset.UtcNow,
            new GeneratedChatMessage("assistant", message),
            true);
    }

    public static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited)
                process.Kill(entireProcessTree: true);
        }
        catch
        {
            // Best effort only; the host should keep serving requests.
        }
    }
}

public sealed class GeneratedPluginCatalogService : IPluginCatalogService
{
    public IReadOnlyList<AiHostPluginManifest> GetPlugins()
    {
        return
        [
            new("native-process-runner", "Native Process Runner", "1.0.0", "IInferenceRunner", true, "Loads compatible local model files through an approved executable; no upstream AI-host proxying."),
            new("pythonnet-runner", "Python.NET Runner Boundary", "planned", "IInferenceRunner", false, "Requires approved Python runtime, PYTHONNET_PYDLL, package list, and GIL-safe service code."),
            new("powershell-runner", "PowerShell Script Boundary", "planned", "IScriptExecutionService", false, "Requires explicit script files, safe directories, constrained runspace policy, and user approval."),
            new("typescript-client-adapter", "TypeScript Client/Adapter Boundary", "planned", "ASP.NET Core static asset or script adapter", false, "Allowed only when embedded deliberately inside the .NET app as client assets or an approved script layer, not as the control-plane owner."),
            new("onnx-runtime-runner", "ONNX Runtime Runner Boundary", "planned", "IInferenceRunner", false, "Only for compatible ONNX models; not a universal LLM replacement.")
        ];
    }
}

public sealed class PermissionGatedScriptExecutionService(IOptions<AiHostRuntimeOptions> options) : IScriptExecutionService
{
    public ScriptExecutionPlan CreatePlan(string scriptKind, string target, bool userApproved)
    {
        var allowed = userApproved && (scriptKind.Equals("powershell", StringComparison.OrdinalIgnoreCase)
            ? options.Value.AllowPowerShellScripts
            : options.Value.AllowPythonNet);

        return new ScriptExecutionPlan(
            scriptKind,
            target,
            allowed,
            allowed
                ? "Approved script boundary. A real implementation must execute in a safe working directory with logs and cancellation."
                : "Not approved. The generated host must not execute scripts until the user enables this path.");
    }
}

public sealed class GeneratedHardwareBudgetService(IOptions<AiHostRuntimeOptions> options) : IHardwareBudgetService
{
    public HardwareBudgetSnapshot GetBudget()
    {
        return new HardwareBudgetSnapshot(
            TargetGpuLoadPercent: 85,
            GpuLayers: options.Value.GpuLayers,
            ContextTokens: options.Value.ContextTokens,
            MaxParallelModels: 1,
            Notes: "Sequential local-model runs are the default until profiling proves heavier concurrency is stable.");
    }
}

public sealed class GeneratedChatTemplateService : IChatTemplateService
{
    public IReadOnlyList<ChatTemplateRule> GetTemplateRules()
    {
        return
        [
            new("Harmony", "Separate analysis/commentary/final markers and always surface final visible text."),
            new("ChatML", "Map role markers, stop sequences, and system/user/assistant boundaries per model."),
            new("Plain prompt", "Use only for /api/generate style requests, not multi-turn chat without conversion."),
            new("Tools", "Keep tool schemas typed and require user approval before native commands or downloads.")
        ];
    }
}

public sealed record RunnerCapabilityReport(
    bool NativeInferenceImplemented,
    IReadOnlyList<string> SupportedFormats,
    string MissingCapability,
    string NextMilestone);

public sealed record AiHostPluginManifest(
    string Id,
    string DisplayName,
    string Version,
    string Contract,
    bool Approved,
    string Notes);

public sealed record ScriptExecutionPlan(
    string ScriptKind,
    string Target,
    bool AllowedToRun,
    string SafetyNote);

public sealed record GeneratedScriptPlanRequest(
    string ScriptKind,
    string Target,
    bool UserApproved);

public sealed record HardwareBudgetSnapshot(
    int TargetGpuLoadPercent,
    int GpuLayers,
    int ContextTokens,
    int MaxParallelModels,
    string Notes);

public sealed record ChatTemplateRule(string Name, string Rule);