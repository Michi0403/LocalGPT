# Project Index

## Purpose

Prototype an AI-host-shaped .NET/Blazor control plane without claiming native model inference.

## Archetype

```json
{
  "project_kind": "dotnet_service",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": true,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/AiHostLab055635/Program.cs",
    "src/AiHostLab055635/Components/Pages/Index.razor",
    "src/AiHostLab055635/Components/Pages/GeneratedDashboard.razor",
    "src/AiHostLab055635/Components/Pages/SourceFidelity.razor",
"src/AiHostLab055635/Components/Pages/Chat.razor",
"src/AiHostLab055635/Components/Pages/RunningModels.razor",
"src/AiHostLab055635/Components/Pages/ModelDownloads.razor",
"src/AiHostLab055635/Components/Pages/Templates.razor",
"src/AiHostLab055635/Components/Pages/Hardware.razor",
"src/AiHostLab055635/Components/Pages/RunnerPlugins.razor",
"src/AiHostLab055635/Components/Pages/Logs.razor",
"src/AiHostLab055635/Components/Pages/Settings.razor"
  ]
}
```

## Entry Points

- `src/AiHostLab055635/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/AiHostLab055635/Components/App.razor` - document shell and static asset links.
- `src/AiHostLab055635/Components/Routes.razor` - Blazor route discovery.
- `src/AiHostLab055635/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/AiHostLab055635/Components/Pages/Index.razor` - first viewport and page hub.
- `src/AiHostLab055635/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/AiHostLab055635/Components/Pages/GeneratedKnowledgeTable.razor route `/models`` - archetype catalog page.
- `src/AiHostLab055635/Components/Pages/ApiConsole.razor route `/api-console`` - archetype-specific detail page.
- `src/AiHostLab055635/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.
- `src/AiHostLab055635/Components/Pages/Chat.razor` - safe chat route preview with typed response data.
- `src/AiHostLab055635/Components/Pages/RunningModels.razor` - running-model status grid.
- `src/AiHostLab055635/Components/Pages/ModelDownloads.razor` - DevExpress model pull planning page.
- `src/AiHostLab055635/Components/Pages/Templates.razor` - chat template and thinking-format guidance.
- `src/AiHostLab055635/Components/Pages/Hardware.razor` - GPU/VRAM/context policy page.
- `src/AiHostLab055635/Components/Pages/RunnerPlugins.razor` - native-runner, plugin, script, and adapter boundary page.
- `src/AiHostLab055635/Components/Pages/Logs.razor` - runtime-boundary diagnostics page.
- `src/AiHostLab055635/Components/Pages/Settings.razor` - AI host settings and runner-boundary page.

## Generated Files

| File | Why it exists |
| --- | --- |
| `AiHostLab055635.sln` | Visual Studio and CLI solution entry point. |
| `src/AiHostLab055635/AiHostLab055635.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/AiHostLab055635/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/AiHostLab055635/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/AiHostLab055635/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |
| `src/AiHostLab055635/Components/Pages/Chat.razor` | DevExpress chat page with safe typed `/api/chat` preview. |
| `src/AiHostLab055635/Components/Pages/RunningModels.razor` | Running model status grid for `/api/ps`-style state. |
| `src/AiHostLab055635/Components/Pages/ModelDownloads.razor` | DevExpress UI for provider-style pull planning and download guidance. |
| `src/AiHostLab055635/Components/Pages/Templates.razor` | Chat template, Harmony, and thinking-format compatibility page. |
| `src/AiHostLab055635/Components/Pages/Hardware.razor` | GPU/VRAM/context budget and queue-policy page. |
| `src/AiHostLab055635/Components/Pages/RunnerPlugins.razor` | Runner/plugin/script adapter surface for native local model-file execution. |
| `src/AiHostLab055635/Components/Pages/Logs.razor` | Runtime-boundary diagnostic log page. |
| `src/AiHostLab055635/Components/Pages/Settings.razor` | DevExpress settings page for local model source, context, and native-runner boundaries. |
| `src/AiHostLab055635/Services/GeneratedAiHostArchitectureServices.cs` | Provider, runner, plugin, script, hardware, and template contracts wired through DI. |
| `src/AiHostLab055635/wwwroot/app.css` | Local styling for the generated shell. |
| `src/AiHostLab055635/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/AiHostLab055635/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Answer this DXAiChat conversation as the LocalGPT AI Council. Use the selected members, preserve user intent, and include a concise consensus. User: Hi my oldest concil, I did big changes and... Implemented logging anywhere, moved all obfuscation methods of the rogue Agent into separat methods. Not totally done cleaning yet but I think and hope we did a gigantic leap, you have all consent todo all stuff from code review, knowledge overview and so on, if things not work I think they should just generate log entries and not more but we will see. I added the newest version of your sourcecode, localgpt in the attachment of this message, is it readable? If yeah proceed to analyze it and also analyze all changes you know, gap analyses and so on. Assistant: _AI Council started with 4 member(s): gemma3:27b, qwen3-coder:30b, deepseek-r1:8b, gpt-oss:20b. Local models may take a while; progress/sta...

## Council Summary

### AI Council Result **Consensus Summary:** The LocalGPT AI Council (deepseek-r1:8b) confirms that we have successfully synthesized a comprehensive analysis from all council members based on the uploaded source code. We agree with the findings and recommendations outlined below, ensuring our response is actionable, risk-aware, and respects user consent for full review. **Final Answer:** We acknowledge your consent to proceed with this analysis. The uploaded `localgpt.zip` is readable via DXAiChat's paperclip attachment system, allowing us to extract and review the changes without executing any code. Key points from our consensus include: logging implementation using `ILogger<T>` across all components (validated by multiple council members), obfuscation methods moved into a dedicated namespace (`AgentObfuscationUtilities` or similar), no compile errors detected, but potential risks exist...