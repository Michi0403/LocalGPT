# Project Index

## Purpose

Prototype a LocalGPT/TacosPortalOpen-style AI Council feature workspace with reviewable Blazor pages.

## Archetype

```json
{
  "project_kind": "localgpt_feature",
  "complexity": "normal",
  "needs_datagen": false,
  "needs_tests": true,
  "needs_native_commands": false,
  "needs_index": true,
  "needs_version_resolver": false,
  "expected_entrypoints": [
    "src/TacosPortal131218/Program.cs",
    "src/TacosPortal131218/Components/Pages/Index.razor",
    "src/TacosPortal131218/Components/Pages/GeneratedDashboard.razor",
    "src/TacosPortal131218/Components/Pages/SourceFidelity.razor"
  ]
}
```

## Entry Points

- `src/TacosPortal131218/Program.cs` - ASP.NET Core service registration, DevExpress setup, and app pipeline.
- `src/TacosPortal131218/Components/App.razor` - document shell and static asset links.
- `src/TacosPortal131218/Components/Routes.razor` - Blazor route discovery.
- `src/TacosPortal131218/Components/GeneratedNavigation.razor` - generated app navigation.
- `src/TacosPortal131218/Components/Pages/Index.razor` - first viewport and page hub.
- `src/TacosPortal131218/Components/Pages/GeneratedDashboard.razor` - health/status grid.
- `src/TacosPortal131218/Components/Pages/GeneratedKnowledgeTable.razor route `/knowledge`` - archetype catalog page.
- `src/TacosPortal131218/Components/Pages/ImplementationPlan.razor route `/implementation-plan`` - archetype-specific detail page.
- `src/TacosPortal131218/Components/Pages/SourceFidelity.razor` - source-fidelity review grid.


## Generated Files

| File | Why it exists |
| --- | --- |
| `TacosPortal131218.sln` | Visual Studio and CLI solution entry point. |
| `src/TacosPortal131218/TacosPortal131218.csproj` | .NET 10 Blazor Web App project with DevExpress dependency. |
| `src/TacosPortal131218/Services/GeneratedHealthSummaryService.cs` | Typed demo service instead of Razor-only fake data. |
| `src/TacosPortal131218/Services/GeneratedSourceFidelityService.cs` | Typed evidence that the sandbox preserves source workflows or marks capability gaps. |
| `src/TacosPortal131218/Models/GeneratedHealthCard.cs` | Shared model records for grids/catalog rows. |

| `src/TacosPortal131218/wwwroot/app.css` | Local styling for the generated shell. |
| `src/TacosPortal131218/wwwroot/icons/nav/*-line.svg` | Default navigation icon style. |
| `src/TacosPortal131218/wwwroot/icons/nav/*-solid.svg` | Hover/focus navigation icon style. |
| `PROJECT_INDEX.md` | Required generated-project map and archetype declaration. |
| `ARCHITECTURE.md` | Explains why this artifact differs from other project types. |
| `SOURCE_FIDELITY.md` | Explains why a compiling artifact still needs architectural fidelity review. |
| `PROMISE_MAP.md` | Maps the council's promised workflows into generated modules and review surfaces. |
| `DESIGN_REVIEW.md` | Explains layout choices, DevExpress components, mocked pieces, and follow-up wiring. |
| `BUILD_AND_RUN.md` | Exact restore/build/run commands and expected checks. |
| `.localgpt-generation.json` | Machine-readable generation contract. |
| `LocalGPT.GenerationManifest.json` | LocalGPT artifact metadata and safety notes. |

## Validation Status

Generated only. The LocalGPT artifact service validated the required file contract before zipping. Run `dotnet build` before treating this as build-passed.

## Original Request

Generate a downloadable whole solution zip that can stand in for TacosPortalOpen as a server-interactive DevExpress/Blazor system. It must represent the real architecture: multi-project/core service topology, Telegram or message-event ingestion, normalized persistence, worker services, notifications/logging, custom security/admin UI, optional WASM client, WinUI/WebView2 wrapper boundary, and a sanitized simpler bot backend implementation.

## Council Summary

Benchmark answer: create a full TacosPortalOpen-style multi-host/event-ingestion solution zip with Telegram ingestion, persistence, workers, admin, client-shell boundaries, and source-fidelity docs. Include Implementation artifact request.