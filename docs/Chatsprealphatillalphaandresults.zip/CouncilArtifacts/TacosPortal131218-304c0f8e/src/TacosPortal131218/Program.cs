using DevExpress.Blazor;
using Microsoft.AspNetCore.Mvc;
using TacosPortal131218.Components;
using TacosPortal131218.Models;
using TacosPortal131218.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddDevExpressBlazor(options => options.SizeMode = SizeMode.Small);
builder.Services.AddSingleton<GeneratedHealthSummaryService>();
builder.Services.AddSingleton<ISourceFidelityService, GeneratedSourceFidelityService>();


var app = builder.Build();

app.UseStaticFiles();
app.UseAntiforgery();
app.MapGet("/__generated/health", (GeneratedHealthSummaryService service) => service.GetCards());

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();