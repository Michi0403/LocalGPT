# Living Cities Reference Benchmark

This generated datapack was shaped against the provided early `living_cities.zip` reference.

Reference traits preserved:

- namespace: `living_cities`
- singular Minecraft 1.21 datapack folders: `data/<namespace>/function` and `data/minecraft/tags/function`
- `core/load` and `core/tick` entry points
- scoreboard objectives for year, population, food, security, prestige, birth year, menu triggers, scan timer, and buildings
- storage areas for city, chronicle, and personalities
- trigger/menu-driven administration book
- no full-world scans in the tick path; scheduled city-local checks only

Improvements over the early reference:

- no `.mcfunction.txt` placeholder files
- build helper validates root zip layout, function tags, singular `function` folders, leading slash mistakes, root storage reset syntax, and `function namespace:path` references
- generated output includes food, security, chronicle, quests, and building functions as real `.mcfunction` files
- town hall UI is available through both the admin book and `/function benchmark_borough:ui/townhall`
- `city/register_banner` includes a visible `say LC register_banner loaded` smoke line so testers can separate discovery problems from command behavior

Remaining needs before your friend tests in a real world:

- confirm the exact Minecraft Java version and pack format
- run `/reload`, `/datapack list`, and `/function benchmark_borough:ui/townhall`
- decide whether banner registration should stay menu-based or become a stricter raycast/block-position workflow