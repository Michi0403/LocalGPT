# Living Cities 0.1 - LocalGPT Starter Plan

User request:

implementation-request smoke: generate a downloadable Minecraft Java 26.1 vanilla datapack zip named Benchmark Borough. The zip root must contain pack.mcmeta and data/ directly. Include load/tick tags, singular function folders, storage/scoreboard setup, city/register_banner, and validation notes.

## Critical path

1. Datapack/data structure
2. Scoreboards or server-side saved data
3. City founding
4. Citizen registration
5. Population management
6. Minimal town hall UI/report

## Performance principles

- Prefer city-level aggregate simulation over ticking every villager.
- Avoid world-wide scans.
- Use registered city areas, local checks, and event-driven updates.
- Store birth year instead of recalculating and persisting age.
- Keep town hall output useful as both player UI and debug surface.

## Starter implementation included

- vanilla datapack structure using `data/<namespace>/function`
- Minecraft `load` and `tick` function tags
- `lc_*` scoreboard objectives
- `living_cities:city`, `living_cities:chronicle`, and `living_cities:personalities` storage
- trigger-based town hall/admin-book UI
- city founding, citizen registration, population, food, security, chronicle, quest, and building functions
- `build-local.ps1` validator that checks JSON, missing functions, placeholder files, and function references before zipping

## Missing LocalGPT feature report

- Add a Minecraft Java runtime harness that copies the generated zip into a selected test world's `datapacks` folder and runs `/reload`.
- Add optional command syntax validation against the exact installed Minecraft server version.
- Add version-aware datapack `pack_format` lookup from the installed Minecraft version manifest.
- Add Bedrock behavior/resource pack exporter as a separate target, not mixed into Java mod generation.