tellraw @s [{"text":"=== Living Cities Chronicle ===","color":"gold","bold":true}]
tellraw @s [{"storage":"benchmark_borough:chronicle","nbt":"events"}]