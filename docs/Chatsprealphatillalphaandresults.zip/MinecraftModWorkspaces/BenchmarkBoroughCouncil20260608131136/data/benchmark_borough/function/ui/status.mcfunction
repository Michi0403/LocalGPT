tellraw @s [{"text":"=== Living Cities Status ===","color":"gold","bold":true}]
execute if data storage benchmark_borough:city {founded:1b} run tellraw @s [{"text":"City founded: ","color":"gray"},{"text":"yes","color":"green"}]
execute unless data storage benchmark_borough:city {founded:1b} run tellraw @s [{"text":"City founded: ","color":"gray"},{"text":"no","color":"red"}]
tellraw @s [{"text":"Population: ","color":"gray"},{"storage":"benchmark_borough:city","nbt":"population"}]
tellraw @s [{"text":"Food: ","color":"gray"},{"storage":"benchmark_borough:city","nbt":"food"}]
tellraw @s [{"text":"Security: ","color":"gray"},{"storage":"benchmark_borough:city","nbt":"security"}]
tellraw @s [{"text":"Houses: ","color":"gray"},{"storage":"benchmark_borough:city","nbt":"houses"}]
tellraw @s [{"text":"Next: use the admin book or /function benchmark_borough:ui/townhall","color":"green"}]
function benchmark_borough:citizens/status