data merge storage benchmark_borough:city {founded:1b,year:1,population:0,food:100,security:100,prestige:0,houses:0,workplaces:0,founder:{x:0,y:0,z:0},banner:{x:0,y:0,z:0}}
execute store result storage benchmark_borough:city year int 1 run scoreboard players get #year lc_year
execute store result storage benchmark_borough:city founder.x int 1 run data get entity @s Pos[0] 1
execute store result storage benchmark_borough:city founder.y int 1 run data get entity @s Pos[1] 1
execute store result storage benchmark_borough:city founder.z int 1 run data get entity @s Pos[2] 1
scoreboard players set #food lc_food 100
scoreboard players set #security lc_security 100
scoreboard players set #prestige lc_prestige 0
function benchmark_borough:citizens/register
function benchmark_borough:city/update_population
function benchmark_borough:chronicle/add_event
tellraw @a [{"text":"[Living Cities] ","color":"gold"},{"text":"A city was founded. Register the banner from the town hall menu next."}]