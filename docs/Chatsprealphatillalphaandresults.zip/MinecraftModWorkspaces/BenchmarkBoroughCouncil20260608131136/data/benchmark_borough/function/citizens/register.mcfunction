execute unless data storage benchmark_borough:city {founded:1b} run return 0
scoreboard players set #registered_this_scan lc_population 0
execute as @e[type=minecraft:villager,distance=..96,tag=!lc_citizen] at @s run function benchmark_borough:citizens/detect_new
function benchmark_borough:citizens/aging
function benchmark_borough:citizens/personalities