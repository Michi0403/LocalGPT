tag @s add lc_citizen
scoreboard players operation @s lc_birth_year = #year lc_year
scoreboard players add #registered_this_scan lc_population 1