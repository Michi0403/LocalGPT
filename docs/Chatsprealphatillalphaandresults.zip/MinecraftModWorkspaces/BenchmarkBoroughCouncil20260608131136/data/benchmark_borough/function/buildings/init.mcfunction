scoreboard players set #houses lc_buildings 0
scoreboard players set #workplaces lc_buildings 0