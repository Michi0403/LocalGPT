scoreboard players set #food_production lc_tmp 0
scoreboard players set #food_counter lc_tmp 0
execute store result score #food_counter lc_tmp if entity @e[type=minecraft:villager,tag=lc_citizen,distance=..96,nbt={VillagerData:{profession:"minecraft:farmer"}}]
scoreboard players operation #food_production lc_tmp += #food_counter lc_tmp
execute store result score #food_counter lc_tmp if entity @e[type=minecraft:villager,tag=lc_citizen,distance=..96,nbt={VillagerData:{profession:"minecraft:fisherman"}}]
scoreboard players operation #food_production lc_tmp += #food_counter lc_tmp
execute store result score #food_counter lc_tmp if entity @e[type=minecraft:villager,tag=lc_citizen,distance=..96,nbt={VillagerData:{profession:"minecraft:butcher"}}]
scoreboard players operation #food_production lc_tmp += #food_counter lc_tmp
execute store result score #food_counter lc_tmp if entity @e[type=minecraft:villager,tag=lc_citizen,distance=..96,nbt={VillagerData:{profession:"minecraft:shepherd"}}]
scoreboard players operation #food_production lc_tmp += #food_counter lc_tmp