data modify storage benchmark_borough:city set value {}
data modify storage benchmark_borough:chronicle set value {events:[]}
data modify storage benchmark_borough:personalities set value {notables:[]}
tag @e[type=minecraft:villager,tag=lc_citizen] remove lc_citizen
tag @e[type=minecraft:villager,tag=lc_personality] remove lc_personality
scoreboard players set #population lc_population 0
scoreboard players set #food lc_food 100
scoreboard players set #security lc_security 100
scoreboard players set #houses lc_buildings 0
function benchmark_borough:core/load
tellraw @s [{"text":"[Living Cities] ","color":"yellow"},{"text":"Test city state reset."}]