function benchmark_borough:security/golems
function benchmark_borough:security/nightwatch
execute store result storage benchmark_borough:city security int 1 run scoreboard players get #security lc_security