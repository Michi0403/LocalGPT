scoreboard players set #golems lc_tmp 0
scoreboard players set #security_factor lc_tmp 20
execute store result score #golems lc_tmp if entity @e[type=minecraft:iron_golem,distance=..96]
scoreboard players operation #security lc_security = #golems lc_tmp
scoreboard players operation #security lc_security *= #security_factor lc_tmp