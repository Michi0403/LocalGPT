# Scheduled aggregate simulation. Keep this local to the selected city area.
execute unless data storage benchmark_borough:city {founded:1b} run return 0
function benchmark_borough:citizens/register
function benchmark_borough:city/update_population
function benchmark_borough:food/update
function benchmark_borough:security/update
function benchmark_borough:quests/update
function benchmark_borough:chronicle/update