execute if score #houses lc_buildings matches ..0 run data merge storage living_cities:city {quest:"Register at least one house."}
execute if score #food lc_food matches ..20 run data merge storage living_cities:city {quest:"Increase food production."}
execute if score #security lc_security matches ..20 run data merge storage living_cities:city {quest:"Improve security."}