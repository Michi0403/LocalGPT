function living_cities:food/production
function living_cities:food/consumption
scoreboard players operation #food lc_food += #food_production lc_tmp
scoreboard players operation #food lc_food -= #food_consumption lc_tmp
execute if score #food lc_food matches ..0 run tellraw @a [{"text":"[Living Cities] ","color":"red"},{"text":"Food stores are empty. Growth and migration should pause in the next milestone."}]
execute store result storage living_cities:city food int 1 run scoreboard players get #food lc_food