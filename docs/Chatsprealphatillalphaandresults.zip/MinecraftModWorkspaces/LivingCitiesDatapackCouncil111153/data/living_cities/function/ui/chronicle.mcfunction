tellraw @s [{"text":"=== Living Cities Chronicle ===","color":"gold","bold":true}]
tellraw @s [{"storage":"living_cities:chronicle","nbt":"events"}]