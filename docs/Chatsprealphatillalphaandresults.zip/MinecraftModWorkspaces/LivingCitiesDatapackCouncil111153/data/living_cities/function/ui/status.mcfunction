tellraw @s [{"text":"=== Living Cities Status ===","color":"gold","bold":true}]
execute if data storage living_cities:city {founded:1b} run tellraw @s [{"text":"City founded: ","color":"gray"},{"text":"yes","color":"green"}]
execute unless data storage living_cities:city {founded:1b} run tellraw @s [{"text":"City founded: ","color":"gray"},{"text":"no","color":"red"}]
tellraw @s [{"text":"Population: ","color":"gray"},{"storage":"living_cities:city","nbt":"population"}]
tellraw @s [{"text":"Food: ","color":"gray"},{"storage":"living_cities:city","nbt":"food"}]
tellraw @s [{"text":"Security: ","color":"gray"},{"storage":"living_cities:city","nbt":"security"}]
tellraw @s [{"text":"Houses: ","color":"gray"},{"storage":"living_cities:city","nbt":"houses"}]
tellraw @s [{"text":"Next: use the admin book or /function living_cities:ui/townhall","color":"green"}]
function living_cities:citizens/status