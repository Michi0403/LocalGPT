# Living Cities tick stays small: menu handling every tick, simulation every 5 seconds.
execute as @a[tag=!lc_received_book] run function living_cities:ui/give_admin_book
scoreboard players enable @a lc_menu

execute as @a[scores={lc_menu=1}] at @s run function living_cities:city/create
execute as @a[scores={lc_menu=2}] at @s run function living_cities:ui/status
execute as @a[scores={lc_menu=3}] at @s run function living_cities:city/register_banner
execute as @a[scores={lc_menu=4}] at @s run function living_cities:buildings/register_house
execute as @a[scores={lc_menu=5}] at @s run function living_cities:ui/chronicle
execute as @a[scores={lc_menu=6}] at @s run function living_cities:debug/reset_city
scoreboard players set @a[scores={lc_menu=1..}] lc_menu 0

scoreboard players add #tick lc_scan_timer 1
execute if score #tick lc_scan_timer matches 100.. as @a[limit=1,sort=nearest] at @s run function living_cities:core/schedule
execute if score #tick lc_scan_timer matches 100.. run scoreboard players set #tick lc_scan_timer 0