# Scheduled aggregate simulation. Keep this local to the selected city area.
execute unless data storage living_cities:city {founded:1b} run return 0
function living_cities:citizens/register
function living_cities:city/update_population
function living_cities:food/update
function living_cities:security/update
function living_cities:quests/update
function living_cities:chronicle/update