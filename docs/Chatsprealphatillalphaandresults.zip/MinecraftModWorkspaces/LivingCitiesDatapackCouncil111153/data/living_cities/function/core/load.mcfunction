# Living Cities 0.1 - core load
# Re-running /reload may print "already exists" warnings for objectives; that is harmless.
scoreboard objectives add lc_year dummy "LC Year"
scoreboard objectives add lc_population dummy "LC Population"
scoreboard objectives add lc_food dummy "LC Food"
scoreboard objectives add lc_security dummy "LC Security"
scoreboard objectives add lc_prestige dummy "LC Prestige"
scoreboard objectives add lc_birth_year dummy "LC Birth Year"
scoreboard objectives add lc_scan_timer dummy "LC Scan Timer"
scoreboard objectives add lc_menu trigger "Living Cities"
scoreboard objectives add lc_buildings dummy "LC Buildings"
scoreboard objectives add lc_tmp dummy "LC Temp"

scoreboard players set #year lc_year 1
scoreboard players set #population lc_population 0
scoreboard players set #food lc_food 100
scoreboard players set #security lc_security 100
scoreboard players set #prestige lc_prestige 0
scoreboard players set #tick lc_scan_timer 0
scoreboard players set #houses lc_buildings 0
scoreboard players set #workplaces lc_buildings 0
scoreboard players set #registered_this_scan lc_population 0

data merge storage living_cities:city {founded:0b,year:1,population:0,food:100,security:100,prestige:0,houses:0,workplaces:0}
data merge storage living_cities:chronicle {events:[]}
data merge storage living_cities:personalities {notables:[]}

function living_cities:buildings/init
function living_cities:city/register_banner
tellraw @a [{"text":"[Living Cities] ","color":"green"},{"text":"Datapack loaded. Use /function living_cities:ui/townhall or the admin book."}]