execute unless data storage living_cities:city {founded:1b} run tellraw @s [{"text":"[Living Cities] ","color":"red"},{"text":"Found a city before registering houses."}]
execute if data storage living_cities:city {founded:1b} run scoreboard players add #houses lc_buildings 1
execute if data storage living_cities:city {founded:1b} store result storage living_cities:city houses int 1 run scoreboard players get #houses lc_buildings
execute if data storage living_cities:city {founded:1b} run tellraw @s [{"text":"[Living Cities] ","color":"green"},{"text":"House registered for the current city."}]