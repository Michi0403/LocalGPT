execute unless data storage living_cities:city {founded:1b} run return 0
scoreboard players set #registered_this_scan lc_population 0
execute as @e[type=minecraft:villager,distance=..96,tag=!lc_citizen] at @s run function living_cities:citizens/detect_new
function living_cities:citizens/aging
function living_cities:citizens/personalities