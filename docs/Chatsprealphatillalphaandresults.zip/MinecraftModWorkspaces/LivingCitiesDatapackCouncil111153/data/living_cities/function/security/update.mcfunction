function living_cities:security/golems
function living_cities:security/nightwatch
execute store result storage living_cities:city security int 1 run scoreboard players get #security lc_security