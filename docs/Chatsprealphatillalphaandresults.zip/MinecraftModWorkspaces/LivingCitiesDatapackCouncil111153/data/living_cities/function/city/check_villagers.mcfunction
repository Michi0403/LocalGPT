scoreboard players set #nearby_villagers lc_tmp 0
execute store result score #nearby_villagers lc_tmp if entity @e[type=minecraft:villager,distance=..96]
execute if score #nearby_villagers lc_tmp matches 2.. run function living_cities:city/create_new
execute unless score #nearby_villagers lc_tmp matches 2.. run tellraw @s [{"text":"[Living Cities] ","color":"red"},{"text":"At least 2 villagers must be within 96 blocks before founding a city."}]