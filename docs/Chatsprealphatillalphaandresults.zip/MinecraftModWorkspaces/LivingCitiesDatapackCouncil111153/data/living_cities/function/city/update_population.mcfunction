scoreboard players set #population lc_population 0
execute store result score #population lc_population if entity @e[type=minecraft:villager,tag=lc_citizen,distance=..96]
execute store result storage living_cities:city population int 1 run scoreboard players get #population lc_population