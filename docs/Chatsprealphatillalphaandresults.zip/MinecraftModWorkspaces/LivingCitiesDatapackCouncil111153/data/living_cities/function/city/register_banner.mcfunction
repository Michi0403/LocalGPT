say LC register_banner loaded
execute if entity @s[type=minecraft:player] store result storage living_cities:city banner.x int 1 run data get entity @s Pos[0] 1
execute if entity @s[type=minecraft:player] store result storage living_cities:city banner.y int 1 run data get entity @s Pos[1] 1
execute if entity @s[type=minecraft:player] store result storage living_cities:city banner.z int 1 run data get entity @s Pos[2] 1
execute if entity @s[type=minecraft:player] run tellraw @s [{"text":"[Living Cities] ","color":"green"},{"text":"Town banner position registered at your current location."}]