[CmdletBinding()]
param(
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildDir = Join-Path $root "build"
$zipPath = Join-Path $buildDir "BenchmarkBoroughCouncil20260608131203-datapack.zip"

New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

function Get-LocalRelativePath {
    param(
        [Parameter(Mandatory = $true)][string]$BasePath,
        [Parameter(Mandatory = $true)][string]$Path
    )

    $baseFull = (Resolve-Path $BasePath).Path.TrimEnd("\", "/") + "\"
    $pathFull = (Resolve-Path $Path).Path
    $baseUri = [Uri]$baseFull
    $pathUri = [Uri]$pathFull
    return [Uri]::UnescapeDataString($baseUri.MakeRelativeUri($pathUri).ToString()).Replace("/", "\")
}

$required = @(
    "pack.mcmeta",
    "data\minecraft\tags\function\load.json",
    "data\minecraft\tags\function\tick.json",
    "data\benchmark_borough\function\core\load.mcfunction",
    "data\benchmark_borough\function\core\tick.mcfunction",
    "data\benchmark_borough\function\city\create.mcfunction",
    "data\benchmark_borough\function\citizens\register.mcfunction",
    "data\benchmark_borough\function\food\update.mcfunction",
    "data\benchmark_borough\function\security\update.mcfunction",
    "data\benchmark_borough\function\ui\townhall.mcfunction",
    "data\benchmark_borough\function\ui\status.mcfunction"
)

foreach ($relative in $required) {
    $path = Join-Path $root $relative
    if (-not (Test-Path $path)) {
        throw "Missing datapack file: $relative"
    }
}

$wrapperMcmeta = Get-ChildItem $root -Directory | ForEach-Object { Join-Path $_.FullName "pack.mcmeta" } | Where-Object { Test-Path $_ }
if ($wrapperMcmeta.Count -gt 0) {
    throw "Datapack wrapper folder detected. The zip root must contain pack.mcmeta directly, not a nested project folder."
}

$legacyFunctions = Get-ChildItem (Join-Path $root "data") -Recurse -Directory -Filter "functions"
if ($legacyFunctions.Count -gt 0) {
    throw "Found legacy plural 'functions' folder. Minecraft 1.21+ datapacks use singular 'function'."
}

Get-Content (Join-Path $root "pack.mcmeta") -Raw | ConvertFrom-Json | Out-Null
Get-Content (Join-Path $root "data\minecraft\tags\function\load.json") -Raw | ConvertFrom-Json | Out-Null
Get-Content (Join-Path $root "data\minecraft\tags\function\tick.json") -Raw | ConvertFrom-Json | Out-Null

$txtPlaceholders = Get-ChildItem (Join-Path $root "data") -Recurse -File -Filter "*.mcfunction.txt"
if ($txtPlaceholders.Count -gt 0) {
    throw "Found .mcfunction.txt placeholders. Rename or implement them as .mcfunction files before packaging."
}

$functionIds = @{}
$functionFiles = Get-ChildItem (Join-Path $root "data") -Recurse -File -Filter "*.mcfunction"
foreach ($file in $functionFiles) {
    $relativePath = Get-LocalRelativePath -BasePath $root -Path $file.FullName
    $parts = $relativePath -split "[\\/]"
    $functionIndex = [Array]::IndexOf($parts, "function")
    if ($parts.Length -lt 4 -or $parts[0] -ne "data" -or $functionIndex -lt 2) {
        throw "Invalid function path: $relativePath"
    }

    $namespace = $parts[1]
    $pathParts = $parts[($functionIndex + 1)..($parts.Length - 1)]
    $functionPath = ($pathParts -join "/") -replace "\.mcfunction$", ""
    $functionIds["${namespace}:$functionPath"] = $relativePath
}

$tagFiles = Get-ChildItem (Join-Path $root "data\minecraft\tags\function") -File -Filter "*.json"
foreach ($tag in $tagFiles) {
    $json = Get-Content $tag.FullName -Raw | ConvertFrom-Json
    foreach ($value in $json.values) {
        if (-not $functionIds.ContainsKey([string]$value)) {
            throw "Function tag $($tag.Name) references missing function: $value"
        }
    }
}

$referencePattern = [regex]'(?<![#/])\bfunction\s+([a-z0-9_.-]+:[a-z0-9_./-]+)'
foreach ($file in $functionFiles) {
    $content = Get-Content $file.FullName -Raw
    if ($content -match "(?m)^\s*/") {
        $relativePath = Get-LocalRelativePath -BasePath $root -Path $file.FullName
        throw "Function $relativePath contains a leading slash command. Remove leading / inside .mcfunction files."
    }

    if ($content -match "\bdata\s+remove\s+storage\b") {
        $relativePath = Get-LocalRelativePath -BasePath $root -Path $file.FullName
        throw "Function $relativePath uses 'data remove storage'. Use 'data modify storage <id> set value ...' for root storage reset."
    }

    if ($content -match "\bstore\s+result\s+storage\s+[a-z0-9_.-]+:[a-z0-9_/-]+\.[a-z0-9_.-]+\s+(byte|short|int|long|float|double)\b") {
        $relativePath = Get-LocalRelativePath -BasePath $root -Path $file.FullName
        throw "Function $relativePath appears to put an NBT path into the storage id. Use 'storage namespace:id path int 1', for example 'storage living_cities:city year int 1'."
    }

    foreach ($match in $referencePattern.Matches($content)) {
        $id = $match.Groups[1].Value
        if (-not $functionIds.ContainsKey($id)) {
            $relativePath = Get-LocalRelativePath -BasePath $root -Path $file.FullName
            throw "Function $relativePath references missing function: $id"
        }
    }
}

Compress-Archive -Path (Join-Path $root "pack.mcmeta"), (Join-Path $root "data") -DestinationPath $zipPath
Write-Host "Validated $($functionFiles.Count) mcfunction files."
Write-Host "Created datapack: $zipPath"